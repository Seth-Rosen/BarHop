import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import HomeScreen from "./src/screens/HomeScreen";
import BarListScreen from "./src/screens/BarListScreen";
import BarDetailScreen from "./src/screens/BarDetailScreen";
import DealsScreen from "./src/screens/DealsScreen";

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: "BarHop" }}
        />
        <Stack.Screen
          name="BarList"
          component={BarListScreen}
          options={{ title: "Nearby Bars" }}
        />
        <Stack.Screen
          name="BarDetail"
          component={BarDetailScreen}
          options={{ title: "Bar Details" }}
        />
        <Stack.Screen
          name="Deals"
          component={DealsScreen}
          options={{ title: "Current Deals" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
