
import axios from 'axios';

// API Configuration
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://your-repl-name.your-username.repl.co/api'
  : 'http://localhost:3000/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
});

// API Functions
export const api = {
  // Bar API
  getBars: (filters) => apiClient.get('/bars', { params: filters }),
  getBar: (id) => apiClient.get(`/bars/${id}`),
  searchBars: (query, filters) => apiClient.get('/bars/search', { params: { query, ...filters } }),
  checkInToBar: (barId) => apiClient.post(`/bars/${barId}/checkin`),
  favoriteBar: (barId) => apiClient.post(`/bars/${barId}/favorite`),
  unfavoriteBar: (barId) => apiClient.delete(`/bars/${barId}/favorite`),
  rateBar: (barId, rating, review) => apiClient.post(`/bars/${barId}/rate`, { rating, review }),
  rateStaff: (barId, staffId, rating) => apiClient.post(`/bars/${barId}/staff/${staffId}/rate`, { rating }),
  
  // Deals API
  getDeals: (filters) => apiClient.get('/deals', { params: filters }),
  getDealsByBar: (barId) => apiClient.get(`/deals?barId=${barId}`),
  
  // User API
  getUserProfile: (userId) => apiClient.get(`/users/${userId}`),
  updateUserProfile: (data) => apiClient.put('/users/profile', data),
  getUserFavorites: () => apiClient.get('/users/favorites'),
  getUserCheckins: (userId) => apiClient.get(`/users/${userId}/checkins`),
  followUser: (userId) => apiClient.post(`/users/${userId}/follow`),
  unfollowUser: (userId) => apiClient.delete(`/users/${userId}/follow`),
  
  // Events API
  getEvents: (filters) => apiClient.get('/events', { params: filters }),
  createEvent: (eventData) => apiClient.post('/events', eventData),
  joinEvent: (eventId) => apiClient.post(`/events/${eventId}/join`),
  leaveEvent: (eventId) => apiClient.delete(`/events/${eventId}/join`),
  updateEvent: (eventId, data) => apiClient.put(`/events/${eventId}`, data),
  deleteEvent: (eventId) => apiClient.delete(`/events/${eventId}`),
  
  // Social API
  getFeed: () => apiClient.get('/social/feed'),
  shareActivity: (activityData) => apiClient.post('/social/share', activityData),
  sendInvite: (eventId, userIds) => apiClient.post(`/events/${eventId}/invite`, { userIds }),
  
  // Admin API
  adminLogin: (credentials) => apiClient.post('/admin/login', credentials),
};

// Shared utilities
export const utils = {
  formatPrice: (price) => `$${price.toFixed(2)}`,
  formatDistance: (meters) => {
    if (meters < 1000) return `${Math.round(meters)}m`;
    return `${(meters / 1000).toFixed(1)}km`;
  },
  isValidEmail: (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
  formatTime: (date) => new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  formatDate: (date) => new Date(date).toLocaleDateString(),
  formatDateTime: (date) => `${utils.formatDate(date)} at ${utils.formatTime(date)}`,
  calculateOccupancyColor: (percentage) => {
    if (percentage < 30) return 'success';
    if (percentage < 70) return 'warning';
    return 'error';
  },
  generateShareUrl: (type, id) => `${window.location.origin}/share/${type}/${id}`,
  debounce: (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },
};

// Shared constants
export const CONSTANTS = {
  DEAL_TYPES: {
    HAPPY_HOUR: 'happy_hour',
    FOOD_SPECIAL: 'food_special',
    DRINK_SPECIAL: 'drink_special',
    EVENT: 'event',
    LIVE_MUSIC: 'live_music',
    TRIVIA_NIGHT: 'trivia_night',
    KARAOKE: 'karaoke',
  },
  BAR_CATEGORIES: {
    SPORTS_BAR: 'sports_bar',
    COCKTAIL_BAR: 'cocktail_bar',
    BREWERY: 'brewery',
    WINE_BAR: 'wine_bar',
    DIVE_BAR: 'dive_bar',
    ROOFTOP: 'rooftop',
    DANCE_CLUB: 'dance_club',
    LOUNGE: 'lounge',
  },
  EVENT_TYPES: {
    BAR_HOP: 'bar_hop',
    MEETUP: 'meetup',
    CELEBRATION: 'celebration',
    DATE_NIGHT: 'date_night',
    CASUAL_DRINKS: 'casual_drinks',
  },
  ACTIVITY_TYPES: {
    CHECKIN: 'checkin',
    REVIEW: 'review',
    EVENT_CREATE: 'event_create',
    EVENT_JOIN: 'event_join',
    FAVORITE: 'favorite',
    FOLLOW: 'follow',
  },
  NOTIFICATION_TYPES: {
    EVENT_INVITE: 'event_invite',
    FRIEND_CHECKIN: 'friend_checkin',
    NEW_DEAL: 'new_deal',
    EVENT_UPDATE: 'event_update',
    FRIEND_REQUEST: 'friend_request',
  },
  USER_ROLES: {
    USER: 'user',
    BAR_STAFF: 'bar_staff',
    BAR_MANAGER: 'bar_manager',
    ADMIN: 'admin',
  },
};
