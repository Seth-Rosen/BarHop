
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'Server running', timestamp: new Date().toISOString() });
});

// Bar routes
app.get('/api/bars', (req, res) => {
  // TODO: Implement bar listing
  res.json({ bars: [] });
});

app.get('/api/deals', (req, res) => {
  // TODO: Implement deals listing
  res.json({ deals: [] });
});

// Admin routes
app.post('/api/admin/login', (req, res) => {
  // TODO: Implement admin authentication
  res.json({ message: 'Admin login endpoint' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
