
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Container, AppBar, Toolbar, Typography } from '@mui/material';
import Dashboard from './components/Dashboard';
import BarManagement from './components/BarManagement';
import DealsManagement from './components/DealsManagement';

function App() {
  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            BarHop Admin
          </Typography>
        </Toolbar>
      </AppBar>
      
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/bars" element={<BarManagement />} />
          <Route path="/deals" element={<DealsManagement />} />
        </Routes>
      </Container>
    </>
  );
}

export default App;
