
import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Typography,
  Box,
  Tabs,
  Tab,
  Card,
  CardContent,
  Chip,
  Button,
  Rating,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar
} from '@mui/material';
import {
  Close,
  LocationOn,
  Phone,
  Schedule,
  People,
  LocalOffer,
  Star,
  Share,
  Directions
} from '@mui/icons-material';
import { utils, CONSTANTS } from '@barhop/shared';

function TabPanel({ children, value, index, ...other }) {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`bar-tabpanel-${index}`}
      aria-labelledby={`bar-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

function BarDetails({ bar, open, onClose, onCheckIn, onShare, onGetDirections }) {
  const [tabValue, setTabValue] = useState(0);
  
  if (!bar) return null;

  const activeDeals = bar.deals?.filter(deal => deal.isActive) || [];
  const reviews = bar.reviews || [];
  const staff = bar.staff || [];

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      sx={{ '& .MuiDialog-paper': { maxHeight: '90vh' } }}
    >
      <DialogTitle sx={{ m: 0, p: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="h6">{bar.name}</Typography>
        <IconButton onClick={onClose}>
          <Close />
        </IconButton>
      </DialogTitle>

      <DialogContent dividers sx={{ p: 0 }}>
        {/* Header Image */}
        <Box
          sx={{
            height: 200,
            backgroundImage: `url(${bar.imageUrl || '/placeholder-bar.jpg'})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            position: 'relative'
          }}
        >
          <Box
            sx={{
              position: 'absolute',
              bottom: 16,
              left: 16,
              right: 16,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-end'
            }}
          >
            <Box>
              <Typography variant="h4" sx={{ color: 'white', textShadow: '2px 2px 4px rgba(0,0,0,0.8)' }}>
                {bar.name}
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                <Rating value={bar.rating} precision={0.1} size="small" readOnly />
                <Typography variant="body2" sx={{ ml: 1, color: 'white' }}>
                  {bar.rating} ({bar.reviewCount} reviews)
                </Typography>
              </Box>
            </Box>
            
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button variant="contained" onClick={() => onCheckIn?.(bar.id)}>
                Check In
              </Button>
              <IconButton onClick={() => onShare?.(bar)} sx={{ color: 'white' }}>
                <Share />
              </IconButton>
              <IconButton onClick={() => onGetDirections?.(bar)} sx={{ color: 'white' }}>
                <Directions />
              </IconButton>
            </Box>
          </Box>
        </Box>

        {/* Quick Info */}
        <Box sx={{ p: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <LocationOn color="action" sx={{ mr: 1 }} />
            <Typography variant="body2">{bar.address}</Typography>
          </Box>
          
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <Phone color="action" sx={{ mr: 1 }} />
            <Typography variant="body2">{bar.phone}</Typography>
          </Box>
          
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Schedule color={bar.isOpen ? 'success' : 'error'} sx={{ mr: 1 }} />
            <Typography variant="body2" color={bar.isOpen ? 'success.main' : 'error.main'}>
              {bar.isOpen ? 'Open' : 'Closed'} • {bar.hours?.today || 'Hours not available'}
            </Typography>
          </Box>

          {bar.currentOccupancy > 0 && (
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <People color="action" sx={{ mr: 1 }} />
              <Typography variant="body2">
                {bar.currentOccupancy}% capacity • {bar.waitTime ? `${bar.waitTime} min wait` : 'No wait'}
              </Typography>
            </Box>
          )}

          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            {bar.tags?.map((tag) => (
              <Chip key={tag} label={tag} size="small" variant="outlined" />
            ))}
          </Box>
        </Box>

        <Divider />

        {/* Tabs */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={tabValue} onChange={handleTabChange}>
            <Tab label={`Deals (${activeDeals.length})`} />
            <Tab label={`Reviews (${reviews.length})`} />
            <Tab label="Staff" />
            <Tab label="Events" />
          </Tabs>
        </Box>

        {/* Deals Tab */}
        <TabPanel value={tabValue} index={0}>
          {activeDeals.length > 0 ? (
            activeDeals.map((deal) => (
              <Card key={deal.id} sx={{ mb: 2 }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <LocalOffer color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6">{deal.title}</Typography>
                    <Chip 
                      label={deal.type} 
                      size="small" 
                      color="primary" 
                      sx={{ ml: 'auto' }} 
                    />
                  </Box>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    {deal.description}
                  </Typography>
                  <Typography variant="body2">
                    Valid: {deal.validFrom} - {deal.validTo}
                  </Typography>
                  {deal.price && (
                    <Typography variant="h6" color="primary" sx={{ mt: 1 }}>
                      {utils.formatPrice(deal.price)}
                    </Typography>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Typography variant="body2" color="text.secondary">
              No active deals at this time.
            </Typography>
          )}
        </TabPanel>

        {/* Reviews Tab */}
        <TabPanel value={tabValue} index={1}>
          <List>
            {reviews.slice(0, 5).map((review) => (
              <ListItem key={review.id} alignItems="flex-start">
                <ListItemAvatar>
                  <Avatar src={review.user.avatar} alt={review.user.name} />
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="subtitle2">{review.user.name}</Typography>
                      <Rating value={review.rating} size="small" readOnly />
                    </Box>
                  }
                  secondary={
                    <>
                      <Typography variant="body2" component="span">
                        {review.comment}
                      </Typography>
                      {review.staffRatings && (
                        <Box sx={{ mt: 1 }}>
                          {review.staffRatings.map((staffRating) => (
                            <Typography key={staffRating.staffId} variant="caption" display="block">
                              {staffRating.staffName}: {staffRating.rating}/5
                            </Typography>
                          ))}
                        </Box>
                      )}
                    </>
                  }
                />
              </ListItem>
            ))}
          </List>
        </TabPanel>

        {/* Staff Tab */}
        <TabPanel value={tabValue} index={2}>
          <List>
            {staff.map((member) => (
              <ListItem key={member.id}>
                <ListItemAvatar>
                  <Avatar src={member.avatar} alt={member.name} />
                </ListItemAvatar>
                <ListItemText
                  primary={member.name}
                  secondary={
                    <Box>
                      <Typography variant="body2">{member.role}</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                        <Rating value={member.averageRating} size="small" readOnly />
                        <Typography variant="caption" sx={{ ml: 1 }}>
                          ({member.ratingCount} ratings)
                        </Typography>
                      </Box>
                    </Box>
                  }
                />
              </ListItem>
            ))}
          </List>
        </TabPanel>

        {/* Events Tab */}
        <TabPanel value={tabValue} index={3}>
          <Typography variant="body2" color="text.secondary">
            Events functionality coming soon!
          </Typography>
        </TabPanel>
      </DialogContent>
    </Dialog>
  );
}

export default BarDetails;
