
import React from 'react';
import { 
  Card, 
  CardContent, 
  CardMedia, 
  Typography, 
  Chip, 
  Box, 
  IconButton,
  Rating,
  Badge
} from '@mui/material';
import { 
  Favorite, 
  FavoriteBorder, 
  LocalOffer, 
  Schedule, 
  LocationOn,
  People
} from '@mui/icons-material';
import { utils } from '@barhop/shared';

function BarCard({ 
  bar, 
  onFavorite, 
  onSelect, 
  isFavorited = false, 
  showDistance = true,
  compact = false 
}) {
  const handleFavoriteClick = (e) => {
    e.stopPropagation();
    onFavorite?.(bar.id);
  };

  const activeDeals = bar.deals?.filter(deal => deal.isActive) || [];
  const isOpen = bar.isOpen;
  const occupancy = bar.currentOccupancy || 0;

  return (
    <Card 
      sx={{ 
        cursor: 'pointer', 
        mb: 2,
        height: compact ? 120 : 200,
        '&:hover': { elevation: 4 }
      }}
      onClick={() => onSelect?.(bar)}
    >
      <Box sx={{ display: 'flex', height: '100%' }}>
        <CardMedia
          component="img"
          sx={{ width: compact ? 100 : 160 }}
          image={bar.imageUrl || '/placeholder-bar.jpg'}
          alt={bar.name}
        />
        
        <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
          <CardContent sx={{ flex: 1, p: compact ? 1 : 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <Typography variant={compact ? 'h6' : 'h5'} component="div" noWrap>
                {bar.name}
              </Typography>
              <IconButton onClick={handleFavoriteClick} size="small">
                {isFavorited ? <Favorite color="error" /> : <FavoriteBorder />}
              </IconButton>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Rating value={bar.rating} precision={0.1} size="small" readOnly />
              <Typography variant="body2" sx={{ ml: 1 }}>
                ({bar.reviewCount})
              </Typography>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <LocationOn fontSize="small" color="action" />
              <Typography variant="body2" color="text.secondary">
                {bar.address}
                {showDistance && bar.distance && ` • ${utils.formatDistance(bar.distance)}`}
              </Typography>
            </Box>

            {!compact && (
              <Box sx={{ display: 'flex', gap: 1, mb: 1, flexWrap: 'wrap' }}>
                {bar.tags?.slice(0, 3).map((tag) => (
                  <Chip key={tag} label={tag} size="small" variant="outlined" />
                ))}
              </Box>
            )}

            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Schedule fontSize="small" color={isOpen ? 'success' : 'error'} />
                <Typography variant="body2" color={isOpen ? 'success.main' : 'error.main'}>
                  {isOpen ? 'Open' : 'Closed'}
                </Typography>
                
                {occupancy > 0 && (
                  <>
                    <People fontSize="small" color="action" />
                    <Typography variant="body2" color="text.secondary">
                      {occupancy}% full
                    </Typography>
                  </>
                )}
              </Box>

              {activeDeals.length > 0 && (
                <Badge badgeContent={activeDeals.length} color="primary">
                  <LocalOffer color="primary" />
                </Badge>
              )}
            </Box>
          </CardContent>
        </Box>
      </Box>
    </Card>
  );
}

export default BarCard;
