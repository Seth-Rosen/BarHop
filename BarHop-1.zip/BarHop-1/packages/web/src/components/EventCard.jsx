
import React from 'react';
import {
  Card,
  CardContent,
  CardActions,
  Typography,
  Box,
  Avatar,
  AvatarGroup,
  Button,
  Chip,
  IconButton,
  Divider
} from '@mui/material';
import {
  Schedule,
  LocationOn,
  People,
  Share,
  Bookmark,
  BookmarkBorder
} from '@mui/icons-material';

function EventCard({ 
  event, 
  onJoin, 
  onShare, 
  onBookmark, 
  isBookmarked = false,
  currentUser 
}) {
  const isCreator = event.createdBy.id === currentUser?.id;
  const isJoined = event.attendees?.some(attendee => attendee.id === currentUser?.id);
  const canJoin = !isJoined && !isCreator;

  return (
    <Card sx={{ mb: 2 }}>
      <CardContent>
        {/* Event Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
          <Box sx={{ flex: 1 }}>
            <Typography variant="h6" gutterBottom>
              {event.title}
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Avatar 
                src={event.createdBy.avatar} 
                alt={event.createdBy.name}
                sx={{ width: 24, height: 24, mr: 1 }}
              />
              <Typography variant="body2" color="text.secondary">
                by {event.createdBy.name}
              </Typography>
            </Box>
          </Box>
          
          <IconButton onClick={() => onBookmark?.(event.id)}>
            {isBookmarked ? <Bookmark color="primary" /> : <BookmarkBorder />}
          </IconButton>
        </Box>

        {/* Event Details */}
        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <Schedule fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
            <Typography variant="body2">
              {new Date(event.startTime).toLocaleDateString()} at {new Date(event.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </Typography>
          </Box>
          
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <LocationOn fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
            <Typography variant="body2">
              {event.startLocation.name}
            </Typography>
          </Box>
        </Box>

        {/* Bar Hop Itinerary */}
        {event.itinerary && event.itinerary.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Bar Hop Itinerary:
            </Typography>
            {event.itinerary.map((stop, index) => (
              <Box key={index} sx={{ display: 'flex', alignItems: 'center', mb: 0.5, ml: 2 }}>
                <Typography variant="body2" color="text.secondary" sx={{ minWidth: 60 }}>
                  {stop.time}
                </Typography>
                <Typography variant="body2">
                  {stop.bar.name}
                </Typography>
                {stop.specialDeal && (
                  <Chip 
                    label={stop.specialDeal} 
                    size="small" 
                    color="primary" 
                    variant="outlined"
                    sx={{ ml: 1 }}
                  />
                )}
              </Box>
            ))}
          </Box>
        )}

        {/* Description */}
        {event.description && (
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            {event.description}
          </Typography>
        )}

        <Divider sx={{ my: 2 }} />

        {/* Attendees */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <People fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
            <Typography variant="body2" sx={{ mr: 2 }}>
              {event.attendees?.length || 0} going
            </Typography>
            
            {event.attendees && event.attendees.length > 0 && (
              <AvatarGroup max={5} sx={{ '& .MuiAvatar-root': { width: 24, height: 24 } }}>
                {event.attendees.map((attendee) => (
                  <Avatar 
                    key={attendee.id}
                    src={attendee.avatar} 
                    alt={attendee.name}
                  />
                ))}
              </AvatarGroup>
            )}
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            {event.tags?.map((tag) => (
              <Chip 
                key={tag} 
                label={tag} 
                size="small" 
                variant="outlined" 
                sx={{ mr: 0.5 }}
              />
            ))}
          </Box>
        </Box>
      </CardContent>

      <CardActions sx={{ justifyContent: 'space-between', px: 2, pb: 2 }}>
        <Box>
          {canJoin && (
            <Button 
              variant="contained" 
              onClick={() => onJoin?.(event.id)}
              sx={{ mr: 1 }}
            >
              Join Event
            </Button>
          )}
          
          {isJoined && (
            <Button 
              variant="outlined" 
              color="success"
              disabled
            >
              Joined
            </Button>
          )}
          
          {isCreator && (
            <Button 
              variant="outlined"
              sx={{ mr: 1 }}
            >
              Edit Event
            </Button>
          )}
        </Box>

        <Button 
          startIcon={<Share />}
          onClick={() => onShare?.(event)}
        >
          Share
        </Button>
      </CardActions>
    </Card>
  );
}

export default EventCard;
