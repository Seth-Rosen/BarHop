
import React, { useState, useEffect } from 'react';
import { 
  Grid, 
  Paper, 
  Typography, 
  TextField, 
  Box, 
  Tab, 
  Tabs,
  IconButton,
  Fab
} from '@mui/material';
import { Search, Map, Event, Add } from '@mui/icons-material';
import BarCard from './BarCard';
import BarDetails from './BarDetails';
import SearchFilters from './SearchFilters';
import EventCard from './EventCard';
import { api, utils } from '@barhop/shared';

function TabPanel({ children, value, index, ...other }) {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`dashboard-tabpanel-${index}`}
      aria-labelledby={`dashboard-tab-${index}`}
      {...other}
    >
      {value === index && <Box>{children}</Box>}
    </div>
  );
}

function Dashboard() {
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [bars, setBars] = useState([]);
  const [events, setEvents] = useState([]);
  const [selectedBar, setSelectedBar] = useState(null);
  const [favoriteBars, setFavoriteBars] = useState(new Set());
  const [filters, setFilters] = useState({});
  const [loading, setLoading] = useState(false);
  const [userLocation, setUserLocation] = useState(null);

  // Mock current user - replace with actual auth
  const currentUser = {
    id: 'user1',
    name: 'John Doe',
    avatar: '/user-avatar.jpg'
  };

  const debouncedSearch = utils.debounce((query, currentFilters) => {
    searchBars(query, currentFilters);
  }, 300);

  useEffect(() => {
    // Get user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => console.error('Error getting location:', error)
      );
    }

    // Load initial data
    loadBars();
    loadEvents();
  }, []);

  useEffect(() => {
    if (searchQuery || Object.keys(filters).length > 0) {
      debouncedSearch(searchQuery, filters);
    } else {
      loadBars();
    }
  }, [searchQuery, filters]);

  const loadBars = async () => {
    setLoading(true);
    try {
      const response = await api.getBars(filters);
      setBars(response.data.bars || []);
    } catch (error) {
      console.error('Error loading bars:', error);
      // Mock data for development
      setBars([
        {
          id: '1',
          name: 'The Rooftop Lounge',
          address: '123 Main St, City',
          rating: 4.5,
          reviewCount: 150,
          distance: 500,
          imageUrl: '/bar1.jpg',
          tags: ['rooftop', 'cocktails', 'romantic'],
          isOpen: true,
          currentOccupancy: 65,
          deals: [
            { id: 'd1', title: 'Happy Hour', isActive: true, type: 'happy_hour' }
          ]
        },
        {
          id: '2',
          name: 'Sports Central',
          address: '456 Oak Ave, City',
          rating: 4.2,
          reviewCount: 89,
          distance: 1200,
          imageUrl: '/bar2.jpg',
          tags: ['sports', 'casual', 'tv'],
          isOpen: true,
          currentOccupancy: 45,
          deals: []
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const loadEvents = async () => {
    try {
      const response = await api.getEvents();
      setEvents(response.data.events || []);
    } catch (error) {
      console.error('Error loading events:', error);
      // Mock data for development
      setEvents([
        {
          id: 'e1',
          title: 'Friday Night Bar Hop',
          description: 'Join us for a fun night exploring the best bars in downtown!',
          startTime: new Date(Date.now() + 86400000).toISOString(),
          createdBy: { id: 'user2', name: 'Sarah Smith', avatar: '/user2.jpg' },
          startLocation: { name: 'The Rooftop Lounge' },
          attendees: [
            { id: 'user3', name: 'Mike Johnson', avatar: '/user3.jpg' },
            { id: 'user4', name: 'Lisa Brown', avatar: '/user4.jpg' }
          ],
          itinerary: [
            { time: '7:00 PM', bar: { name: 'The Rooftop Lounge' }, specialDeal: 'Happy Hour' },
            { time: '9:00 PM', bar: { name: 'Sports Central' } },
            { time: '11:00 PM', bar: { name: 'Dance Floor' } }
          ],
          tags: ['bar hop', 'social']
        }
      ]);
    }
  };

  const searchBars = async (query, searchFilters) => {
    setLoading(true);
    try {
      const response = await api.searchBars(query, searchFilters);
      setBars(response.data.bars || []);
    } catch (error) {
      console.error('Error searching bars:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBarSelect = (bar) => {
    setSelectedBar(bar);
  };

  const handleBarFavorite = async (barId) => {
    try {
      if (favoriteBars.has(barId)) {
        await api.unfavoriteBar(barId);
        setFavoriteBars(prev => {
          const newSet = new Set(prev);
          newSet.delete(barId);
          return newSet;
        });
      } else {
        await api.favoriteBar(barId);
        setFavoriteBars(prev => new Set([...prev, barId]));
      }
    } catch (error) {
      console.error('Error updating favorite:', error);
    }
  };

  const handleEventJoin = async (eventId) => {
    try {
      await api.joinEvent(eventId);
      // Reload events to reflect the change
      loadEvents();
    } catch (error) {
      console.error('Error joining event:', error);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Box sx={{ width: '100%' }}>
      {/* Search Header */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search for bars, deals, or events..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          InputProps={{
            startAdornment: <Search sx={{ mr: 1, color: 'text.secondary' }} />
          }}
          sx={{ mb: 2 }}
        />
        
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="Bars" />
          <Tab label="Map" />
          <Tab label="Events" />
        </Tabs>
      </Paper>

      {/* Tab Content */}
      <TabPanel value={tabValue} index={0}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <SearchFilters
              filters={filters}
              onFiltersChange={setFilters}
              compact={false}
            />
          </Grid>
          
          <Grid item xs={12} md={8}>
            {loading ? (
              <Typography>Loading bars...</Typography>
            ) : bars.length > 0 ? (
              bars.map((bar) => (
                <BarCard
                  key={bar.id}
                  bar={bar}
                  onSelect={handleBarSelect}
                  onFavorite={handleBarFavorite}
                  isFavorited={favoriteBars.has(bar.id)}
                  showDistance={!!userLocation}
                />
              ))
            ) : (
              <Typography variant="body2" color="text.secondary">
                No bars found. Try adjusting your search or filters.
              </Typography>
            )}
          </Grid>
        </Grid>
      </TabPanel>

      <TabPanel value={tabValue} index={1}>
        <Paper sx={{ p: 3, textAlign: 'center' }}>
          <Map sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
          <Typography variant="h6" gutterBottom>
            Map View Coming Soon
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Interactive map with bar locations and real-time information
          </Typography>
        </Paper>
      </TabPanel>

      <TabPanel value={tabValue} index={2}>
        <Box>
          {events.length > 0 ? (
            events.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onJoin={handleEventJoin}
                onShare={(event) => console.log('Share event:', event)}
                onBookmark={(eventId) => console.log('Bookmark event:', eventId)}
                currentUser={currentUser}
              />
            ))
          ) : (
            <Paper sx={{ p: 3, textAlign: 'center' }}>
              <Event sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
              <Typography variant="h6" gutterBottom>
                No Events Yet
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Create your first bar hopping event or join others!
              </Typography>
            </Paper>
          )}
        </Box>
      </TabPanel>

      {/* Floating Action Button */}
      <Fab
        color="primary"
        aria-label="add"
        sx={{ position: 'fixed', bottom: 16, right: 16 }}
        onClick={() => console.log('Create new event/bar')}
      >
        <Add />
      </Fab>

      {/* Bar Details Modal */}
      <BarDetails
        bar={selectedBar}
        open={!!selectedBar}
        onClose={() => setSelectedBar(null)}
        onCheckIn={(barId) => console.log('Check in to:', barId)}
        onShare={(bar) => console.log('Share bar:', bar)}
        onGetDirections={(bar) => console.log('Get directions to:', bar)}
      />
    </Box>
  );
}

export default Dashboard;
