
import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Slider,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Chip,
  TextField,
  Button,
  Collapse,
  IconButton
} from '@mui/material';
import { ExpandMore, ExpandLess, FilterList } from '@mui/icons-material';
import { CONSTANTS } from '@barhop/shared';

function SearchFilters({ 
  filters, 
  onFiltersChange, 
  onApplyFilters, 
  onClearFilters,
  compact = false 
}) {
  const [expanded, setExpanded] = useState(!compact);
  const [localFilters, setLocalFilters] = useState(filters || {
    distance: 5,
    priceRange: [1, 4],
    rating: 3,
    categories: [],
    tags: [],
    amenities: [],
    hasDeals: false,
    isOpen: false,
    maxWaitTime: 30,
    occupancyRange: [0, 100],
    hasEvents: false
  });

  const handleFilterChange = (key, value) => {
    const newFilters = { ...localFilters, [key]: value };
    setLocalFilters(newFilters);
    if (!compact) {
      onFiltersChange?.(newFilters);
    }
  };

  const handleApply = () => {
    onApplyFilters?.(localFilters);
    if (compact) {
      setExpanded(false);
    }
  };

  const handleClear = () => {
    const clearedFilters = {
      distance: 5,
      priceRange: [1, 4],
      rating: 3,
      categories: [],
      tags: [],
      amenities: [],
      hasDeals: false,
      isOpen: false,
      maxWaitTime: 30,
      occupancyRange: [0, 100],
      hasEvents: false
    };
    setLocalFilters(clearedFilters);
    onClearFilters?.(clearedFilters);
  };

  const barCategories = Object.values(CONSTANTS.BAR_CATEGORIES);
  const availableTags = [
    'live music', 'sports', 'dancing', 'rooftop', 'outdoor seating',
    'pool table', 'darts', 'trivia night', 'karaoke', 'craft beer',
    'cocktails', 'wine', 'food', 'late night', 'quiet', 'casual',
    'upscale', 'romantic', 'group friendly'
  ];
  
  const amenities = [
    'WiFi', 'Parking', 'Wheelchair Accessible', 'Pet Friendly',
    'Outdoor Seating', 'Private Rooms', 'TV/Sports', 'Pool Table',
    'Games', 'Live Music', 'Dancing', 'Food Service'
  ];

  return (
    <Card sx={{ mb: 2 }}>
      <CardContent sx={{ pb: compact ? 1 : 2 }}>
        {compact && (
          <Box sx={{ display: 'flex', justifyContent: 'between', alignItems: 'center', mb: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <FilterList sx={{ mr: 1 }} />
              <Typography variant="h6">Filters</Typography>
            </Box>
            <IconButton onClick={() => setExpanded(!expanded)}>
              {expanded ? <ExpandLess /> : <ExpandMore />}
            </IconButton>
          </Box>
        )}

        <Collapse in={expanded}>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 3 }}>
            {/* Distance */}
            <Box>
              <Typography gutterBottom>Distance: {localFilters.distance} km</Typography>
              <Slider
                value={localFilters.distance}
                onChange={(e, value) => handleFilterChange('distance', value)}
                min={0.5}
                max={50}
                step={0.5}
                marks={[
                  { value: 1, label: '1km' },
                  { value: 5, label: '5km' },
                  { value: 10, label: '10km' },
                  { value: 25, label: '25km' }
                ]}
              />
            </Box>

            {/* Price Range */}
            <Box>
              <Typography gutterBottom>
                Price Range: {'$'.repeat(localFilters.priceRange[0])} - {'$'.repeat(localFilters.priceRange[1])}
              </Typography>
              <Slider
                value={localFilters.priceRange}
                onChange={(e, value) => handleFilterChange('priceRange', value)}
                min={1}
                max={4}
                step={1}
                marks={[
                  { value: 1, label: '$' },
                  { value: 2, label: '$$' },
                  { value: 3, label: '$$$' },
                  { value: 4, label: '$$$$' }
                ]}
              />
            </Box>

            {/* Rating */}
            <Box>
              <Typography gutterBottom>Minimum Rating: {localFilters.rating} stars</Typography>
              <Slider
                value={localFilters.rating}
                onChange={(e, value) => handleFilterChange('rating', value)}
                min={1}
                max={5}
                step={0.5}
                marks={[
                  { value: 1, label: '1★' },
                  { value: 3, label: '3★' },
                  { value: 5, label: '5★' }
                ]}
              />
            </Box>

            {/* Occupancy */}
            <Box>
              <Typography gutterBottom>
                Occupancy: {localFilters.occupancyRange[0]}% - {localFilters.occupancyRange[1]}%
              </Typography>
              <Slider
                value={localFilters.occupancyRange}
                onChange={(e, value) => handleFilterChange('occupancyRange', value)}
                min={0}
                max={100}
                step={10}
              />
            </Box>

            {/* Categories */}
            <FormControl fullWidth>
              <InputLabel>Bar Type</InputLabel>
              <Select
                multiple
                value={localFilters.categories}
                onChange={(e) => handleFilterChange('categories', e.target.value)}
                renderValue={(selected) => (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {selected.map((value) => (
                      <Chip key={value} label={value.replace('_', ' ')} size="small" />
                    ))}
                  </Box>
                )}
              >
                {barCategories.map((category) => (
                  <MenuItem key={category} value={category}>
                    {category.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {/* Tags */}
            <FormControl fullWidth>
              <InputLabel>Atmosphere & Features</InputLabel>
              <Select
                multiple
                value={localFilters.tags}
                onChange={(e) => handleFilterChange('tags', e.target.value)}
                renderValue={(selected) => (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {selected.map((value) => (
                      <Chip key={value} label={value} size="small" />
                    ))}
                  </Box>
                )}
              >
                {availableTags.map((tag) => (
                  <MenuItem key={tag} value={tag}>
                    {tag}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>

          {/* Boolean Filters */}
          <Box sx={{ mt: 3 }}>
            <FormGroup row>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={localFilters.hasDeals}
                    onChange={(e) => handleFilterChange('hasDeals', e.target.checked)}
                  />
                }
                label="Has Current Deals"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={localFilters.isOpen}
                    onChange={(e) => handleFilterChange('isOpen', e.target.checked)}
                  />
                }
                label="Open Now"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={localFilters.hasEvents}
                    onChange={(e) => handleFilterChange('hasEvents', e.target.checked)}
                  />
                }
                label="Has Events"
              />
            </FormGroup>
          </Box>

          {/* Action Buttons */}
          {compact && (
            <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
              <Button variant="contained" onClick={handleApply} fullWidth>
                Apply Filters
              </Button>
              <Button variant="outlined" onClick={handleClear} fullWidth>
                Clear All
              </Button>
            </Box>
          )}
        </Collapse>
      </CardContent>
    </Card>
  );
}

export default SearchFilters;
