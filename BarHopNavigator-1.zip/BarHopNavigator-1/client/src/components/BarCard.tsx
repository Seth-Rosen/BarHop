import { Heart, Star, MapPin, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface BarCardProps {
  bar: {
    id: number;
    name: string;
    address: string;
    rating?: number;
    priceLevel?: number;
    photos: string[];
    categories: string[];
    isOpenNow?: boolean;
    reviews?: any[];
  };
  distance?: string;
  isSaved?: boolean;
  onSaveToggle: (barId: number) => void;
  onBarClick: (bar: any) => void;
}

export function BarCard({ bar, distance, isSaved, onSaveToggle, onBarClick }: BarCardProps) {
  const getStatusBadge = () => {
    if (bar.isOpenNow === true) {
      return (
        <div className="absolute bottom-3 left-3 bg-green-500 text-white px-2 py-1 rounded text-xs font-medium">
          Open Now
        </div>
      );
    }
    if (bar.isOpenNow === false) {
      return (
        <div className="absolute bottom-3 left-3 bg-red-500 text-white px-2 py-1 rounded text-xs font-medium">
          Closed
        </div>
      );
    }
    return null;
  };

  const getPriceLevel = () => {
    if (!bar.priceLevel) return "";
    return "$".repeat(Math.min(bar.priceLevel, 4));
  };

  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSaveToggle(bar.id);
  };

  const handleCardClick = () => {
    onBarClick(bar);
  };

  return (
    <Card 
      className="bg-navy-darker rounded-xl overflow-hidden hover:bg-opacity-80 transition-all cursor-pointer card-hover"
      onClick={handleCardClick}
    >
      <div 
        className="relative h-48 bg-cover bg-center"
        style={{
          backgroundImage: bar.photos[0] 
            ? `url(${bar.photos[0]})` 
            : 'url("https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400")'
        }}
      >
        <div className="absolute top-3 right-3 bg-black bg-opacity-60 rounded-full p-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleSaveClick}
            className={`p-0 h-auto hover:bg-transparent ${
              isSaved ? 'text-vibrant-pink' : 'text-white hover:text-vibrant-pink'
            }`}
          >
            <Heart className={`h-5 w-5 ${isSaved ? 'fill-current' : ''}`} />
          </Button>
        </div>
        {getStatusBadge()}
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-lg font-semibold text-white truncate pr-2">{bar.name}</h3>
          {bar.rating && (
            <div className="flex items-center gap-1 flex-shrink-0">
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
              <span className="text-sm text-gray-300">{bar.rating.toFixed(1)}</span>
            </div>
          )}
        </div>
        
        <p className="text-gray-400 text-sm mb-3 line-clamp-2">
          {bar.categories.length > 0 
            ? bar.categories.slice(0, 2).join(", ")
            : "Bar & Restaurant"
          }
        </p>
        
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4 text-gray-300">
            {distance && (
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                <span>{distance}</span>
              </div>
            )}
            {bar.priceLevel && (
              <div className="flex items-center gap-1">
                <DollarSign className="h-4 w-4" />
                <span>{getPriceLevel()}</span>
              </div>
            )}
          </div>
          <span className="text-vibrant-pink font-medium">View Details</span>
        </div>
      </div>
    </Card>
  );
}
