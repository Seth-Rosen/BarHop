import { useState } from "react";
import { Search, MapPin, User } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface SearchHeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSearchSubmit: () => void;
  currentLocation?: string;
  onLocationRequest: () => void;
}

export function SearchHeader({ 
  searchQuery, 
  onSearchChange, 
  onSearchSubmit,
  currentLocation, 
  onLocationRequest 
}: SearchHeaderProps) {
  return (
    <header className="bg-navy-darker px-4 py-6 sticky top-0 z-40">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <MapPin className="text-vibrant-pink text-xl" />
          <span className="text-lg font-semibold">Bar Hop</span>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          <User className="h-5 w-5 text-gray-300" />
        </Button>
      </div>
      
      {/* Search Bar */}
      <div className="relative">
        <Input
          type="text"
          placeholder="Search 'bars in New York', 'clubs Chicago', 'pubs London'..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && onSearchSubmit()}
          className="w-full bg-navy-dark text-white placeholder-gray-400 px-4 py-3 rounded-xl border border-gray-600 focus:border-vibrant-pink focus:outline-none transition-colors pr-12"
        />
        <Button
          variant="ghost"
          size="icon"
          onClick={onSearchSubmit}
          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-vibrant-pink hover:text-vibrant-pink"
        >
          <Search className="h-4 w-4" />
        </Button>
      </div>
      
      {/* Location Indicator */}
      <div className="flex items-center gap-2 mt-3 text-sm text-gray-300">
        <MapPin className="h-4 w-4 text-vibrant-pink" />
        <span>{currentLocation || "Getting location..."}</span>
        <Button
          variant="ghost"
          size="sm"
          onClick={onLocationRequest}
          className="text-vibrant-pink hover:text-vibrant-pink ml-auto text-xs p-0 h-auto"
        >
          Change
        </Button>
      </div>
    </header>
  );
}
