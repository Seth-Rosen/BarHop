import { useState } from "react";
import { X, Share2, Heart, Navigation, Plus, Star, MapPin, Phone, Globe, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

interface BarModalProps {
  isOpen: boolean;
  onClose: () => void;
  bar: any;
  isSaved?: boolean;
  onSaveToggle: (barId: number) => void;
  onAddToHop: (bar: any) => void;
}

export function BarModal({ 
  isOpen, 
  onClose, 
  bar, 
  isSaved, 
  onSaveToggle, 
  onAddToHop 
}: BarModalProps) {
  if (!bar) return null;

  const handleSaveToggle = () => {
    onSaveToggle(bar.id);
  };

  const handleAddToHop = () => {
    onAddToHop(bar);
  };

  const handleGetDirections = () => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(bar.address)}`;
    window.open(url, '_blank');
  };

  const getPriceLevel = () => {
    if (!bar.priceLevel) return "";
    return "$".repeat(Math.min(bar.priceLevel, 4));
  };

  const formatPhoneNumber = (phone: string) => {
    if (!phone || typeof phone !== 'string') return "";
    return phone.replace(/^\+1/, "");
  };

  const getOpeningHoursToday = () => {
    if (!bar.openingHours?.weekdayText) return null;
    const today = new Date().getDay();
    const todayIndex = today === 0 ? 6 : today - 1; // Convert to Monday = 0 format
    return bar.openingHours.weekdayText[todayIndex];
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto bg-navy-dark border-navy-darker p-0">
        {/* Header */}
        <DialogHeader className="sticky top-0 bg-navy-darker px-4 py-4 flex flex-row items-center justify-between space-y-0 z-10">
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="rounded-full hover:bg-navy-dark"
          >
            <X className="h-5 w-5 text-gray-300" />
          </Button>
          <h2 className="text-lg font-semibold">Bar Details</h2>
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full hover:bg-navy-dark"
          >
            <Share2 className="h-5 w-5 text-gray-300" />
          </Button>
        </DialogHeader>

        {/* Content */}
        <div className="px-4 pb-6 space-y-6">
          {/* Image Gallery */}
          <div 
            className="relative h-64 bg-cover bg-center rounded-xl"
            style={{
              backgroundImage: bar.photos[0] 
                ? `url(${bar.photos[0]})` 
                : 'url("https://images.unsplash.com/photo-1572116469696-31de0f17cc34?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600")'
            }}
          >
            <div className="absolute top-3 right-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSaveToggle}
                className={`bg-black bg-opacity-60 rounded-full p-3 hover:bg-opacity-80 ${
                  isSaved ? 'text-vibrant-pink' : 'text-white hover:text-vibrant-pink'
                }`}
              >
                <Heart className={`h-6 w-6 ${isSaved ? 'fill-current' : ''}`} />
              </Button>
            </div>
            {bar.isOpenNow !== undefined && (
              <div className={`absolute bottom-3 left-3 px-3 py-1 rounded-full text-sm font-medium ${
                bar.isOpenNow ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
              }`}>
                {bar.isOpenNow ? 'Open Now' : 'Closed'}
              </div>
            )}
          </div>

          {/* Bar Info */}
          <div className="space-y-4">
            <div>
              <h1 className="text-2xl font-bold text-white mb-2">{bar.name}</h1>
              <div className="flex items-center gap-4 text-sm text-gray-300 flex-wrap">
                {bar.rating && (
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span>
                      {bar.rating.toFixed(1)}
                      {bar.reviews && ` (${bar.reviews.length} reviews)`}
                    </span>
                  </div>
                )}
                {bar.priceLevel && (
                  <div className="flex items-center gap-1">
                    <span className="text-vibrant-pink font-medium">{getPriceLevel()}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Categories */}
            {bar.categories.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {bar.categories.slice(0, 3).map((category: string) => (
                  <Badge key={category} variant="secondary" className="bg-navy-darker text-gray-300">
                    {category.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, l => l.toUpperCase())}
                  </Badge>
                ))}
              </div>
            )}

            {/* Opening Hours */}
            {bar.openingHours && (
              <div className="bg-navy-darker rounded-xl p-4">
                <h3 className="font-semibold text-white mb-3 flex items-center gap-2">
                  <Clock className="h-5 w-5 text-vibrant-pink" />
                  Hours
                </h3>
                <div className="space-y-1 text-sm">
                  {bar.openingHours.weekdayText?.map((hours: string, index: number) => {
                    const today = new Date().getDay();
                    const todayIndex = today === 0 ? 6 : today - 1;
                    const isToday = index === todayIndex;
                    
                    return (
                      <div key={index} className={`flex justify-between ${
                        isToday ? 'text-vibrant-pink font-medium' : 'text-gray-300'
                      }`}>
                        <span>{hours.split(': ')[0]}{isToday ? ' (Today)' : ''}</span>
                        <span className={isToday && bar.isOpenNow ? 'text-green-400' : ''}>{hours.split(': ')[1]}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Contact & Location */}
            <div className="bg-navy-darker rounded-xl p-4">
              <h3 className="font-semibold text-white mb-3 flex items-center gap-2">
                <MapPin className="h-5 w-5 text-vibrant-pink" />
                Location & Contact
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-3">
                  <MapPin className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                  <span className="text-gray-300">{bar.address}</span>
                </div>
                {bar.phoneNumber && (
                  <div className="flex items-center gap-3">
                    <Phone className="h-4 w-4 text-gray-400 flex-shrink-0" />
                    <span className="text-gray-300">{formatPhoneNumber(bar.phoneNumber)}</span>
                  </div>
                )}
                {bar.website && (
                  <div className="flex items-center gap-3">
                    <Globe className="h-4 w-4 text-gray-400 flex-shrink-0" />
                    <a 
                      href={bar.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-vibrant-pink hover:underline truncate"
                    >
                      {bar.website.replace(/^https?:\/\//, '').replace(/\/$/, '')}
                    </a>
                  </div>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button 
                onClick={handleGetDirections}
                className="flex-1 bg-vibrant-pink hover:bg-vibrant-pink/90 text-white"
              >
                <Navigation className="h-4 w-4 mr-2" />
                Directions
              </Button>
              <Button 
                onClick={handleAddToHop}
                variant="outline"
                className="flex-1 border-ocean-blue text-ocean-blue hover:bg-ocean-blue hover:text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add to Hop
              </Button>
            </div>

            {/* Reviews */}
            {bar.reviews && bar.reviews.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Recent Reviews</h3>
                <div className="space-y-3">
                  {bar.reviews.slice(0, 3).map((review: any, index: number) => (
                    <div key={index} className="bg-navy-darker rounded-xl p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-vibrant-pink rounded-full flex items-center justify-center">
                            <span className="text-white font-semibold text-sm">
                              {review.author_name?.charAt(0)?.toUpperCase() || review.author?.charAt(0)?.toUpperCase() || "?"}
                            </span>
                          </div>
                          <div>
                            <p className="text-white font-medium">{review.author_name || review.author || "Anonymous"}</p>
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`h-3 w-3 ${
                                    i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-600'
                                  }`} 
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                        <span className="text-gray-400 text-sm">
                          {new Date(review.time).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-gray-300 text-sm">{review.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
