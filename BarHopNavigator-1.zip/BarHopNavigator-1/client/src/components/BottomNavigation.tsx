import { Home, Search, Map, Heart, Route } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'search', icon: Search, label: 'Search' },
    { id: 'map', icon: Map, label: 'Map' },
    { id: 'saved', icon: Heart, label: 'Saved' },
    { id: 'hop', icon: Route, label: 'Hop' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-navy-darker border-t border-navy-darker px-4 py-2 z-50">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map(({ id, icon: Icon, label }) => (
          <Button
            key={id}
            variant="ghost"
            onClick={() => onTabChange(id)}
            className={`flex flex-col items-center gap-1 py-2 px-3 h-auto transition-colors ${
              activeTab === id 
                ? 'text-vibrant-pink' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Icon className="h-5 w-5" />
            <span className="text-xs font-medium">{label}</span>
          </Button>
        ))}
      </div>
    </nav>
  );
}
