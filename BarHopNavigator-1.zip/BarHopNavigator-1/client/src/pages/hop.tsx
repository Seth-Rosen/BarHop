import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Route, Plus, Edit, Trash2, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { barHopApi } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

// Simulated user ID - in a real app this would come from authentication
const USER_ID = "user-1";

export default function HopPage() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newHopName, setNewHopName] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: barHops = [], isLoading } = useQuery({
    queryKey: ['/api/bar-hops', USER_ID],
    queryFn: () => barHopApi.getBarHops(USER_ID),
  });

  const createBarHopMutation = useMutation({
    mutationFn: (name: string) => barHopApi.createBarHop(name, USER_ID),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bar-hops', USER_ID] });
      setIsCreateModalOpen(false);
      setNewHopName("");
      toast({
        title: "Bar Hop Created",
        description: "Your new bar hop has been created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create bar hop",
        variant: "destructive",
      });
    },
  });

  const deleteBarHopMutation = useMutation({
    mutationFn: (id: number) => barHopApi.deleteBarHop(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bar-hops', USER_ID] });
      toast({
        title: "Bar Hop Deleted",
        description: "Bar hop has been deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete bar hop",
        variant: "destructive",
      });
    },
  });

  const handleCreateHop = () => {
    if (newHopName.trim()) {
      createBarHopMutation.mutate(newHopName.trim());
    }
  };

  const handleDeleteHop = (id: number) => {
    if (confirm("Are you sure you want to delete this bar hop?")) {
      deleteBarHopMutation.mutate(id);
    }
  };

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      {/* Header */}
      <header className="bg-navy-darker px-4 py-6 sticky top-0 z-40">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Route className="text-vibrant-pink text-xl" />
            <span className="text-lg font-semibold">Bar Hops</span>
          </div>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button 
                size="sm"
                className="bg-vibrant-pink hover:bg-vibrant-pink/90 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-navy-dark border-navy-darker">
              <DialogHeader>
                <DialogTitle className="text-white">Create New Bar Hop</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="hopName" className="text-white">Bar Hop Name</Label>
                  <Input
                    id="hopName"
                    value={newHopName}
                    onChange={(e) => setNewHopName(e.target.value)}
                    placeholder="Enter a name for your bar hop..."
                    className="bg-navy-darker border-gray-600 text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={handleCreateHop}
                    disabled={!newHopName.trim() || createBarHopMutation.isPending}
                    className="bg-vibrant-pink hover:bg-vibrant-pink/90 text-white flex-1"
                  >
                    {createBarHopMutation.isPending ? "Creating..." : "Create Bar Hop"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="border-gray-600"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <main className="px-4 pb-24">
        {isLoading ? (
          <div className="space-y-4 mt-6">
            {[...Array(2)].map((_, i) => (
              <Card key={i} className="bg-navy-darker p-6 animate-pulse">
                <div className="h-4 bg-gray-600 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-600 rounded w-1/4 mb-4"></div>
                <div className="h-3 bg-gray-600 rounded w-3/4"></div>
              </Card>
            ))}
          </div>
        ) : barHops.length > 0 ? (
          <div className="space-y-4 mt-6">
            {barHops.map((hop: any) => (
              <Card key={hop.id} className="bg-navy-darker p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">{hop.name}</h3>
                    <p className="text-sm text-gray-400">
                      {hop.bars.length} bars • Created {new Date(hop.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-gray-400 hover:text-white"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteHop(hop.id)}
                      className="text-gray-400 hover:text-red-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {hop.bars.length > 0 ? (
                  <div className="space-y-3">
                    {hop.bars.map((bar: any, index: number) => (
                      <div key={bar.id} className="flex items-center gap-3 p-3 bg-navy-dark rounded-lg">
                        <div className="w-8 h-8 bg-vibrant-pink rounded-full flex items-center justify-center text-white font-semibold text-sm">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-white">{bar.name}</h4>
                          <p className="text-sm text-gray-400 flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {bar.address}
                          </p>
                        </div>
                        {bar.rating && (
                          <div className="flex items-center gap-1">
                            <span className="text-yellow-400">★</span>
                            <span className="text-sm text-gray-300">{bar.rating.toFixed(1)}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 border-2 border-dashed border-gray-600 rounded-lg">
                    <Route className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-400 mb-4">No bars added yet</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-vibrant-pink text-vibrant-pink hover:bg-vibrant-pink hover:text-white"
                    >
                      Add Bars
                    </Button>
                  </div>
                )}

                {hop.bars.length > 0 && (
                  <div className="flex gap-2 mt-4">
                    <Button
                      className="bg-vibrant-pink hover:bg-vibrant-pink/90 text-white flex-1"
                    >
                      Start Hop
                    </Button>
                    <Button
                      variant="outline"
                      className="border-ocean-blue text-ocean-blue hover:bg-ocean-blue hover:text-white"
                    >
                      View on Map
                    </Button>
                  </div>
                )}
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Route className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-300 mb-2">No Bar Hops</h3>
            <p className="text-gray-400 mb-6">
              Create your first bar hop to plan your perfect night out.
            </p>
            <Button
              onClick={() => setIsCreateModalOpen(true)}
              className="bg-vibrant-pink hover:bg-vibrant-pink/90 text-white"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Hop
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
