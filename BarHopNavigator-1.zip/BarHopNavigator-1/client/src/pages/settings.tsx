import { useState } from "react";
import { Settings, Key, Users, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function SettingsPage() {
  const { toast } = useToast();

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      {/* Header */}
      <header className="bg-navy-darker px-4 py-6 sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <Settings className="text-vibrant-pink text-xl" />
          <span className="text-lg font-semibold">Settings</span>
        </div>
      </header>

      <main className="px-4 pb-24 space-y-6">


        {/* Friends Section */}
        <Card className="bg-navy-darker p-6 border-navy-darker">
          <div className="flex items-center gap-3 mb-4">
            <Users className="h-5 w-5 text-vibrant-pink" />
            <h2 className="text-lg font-semibold">Friends & Social</h2>
          </div>
          
          <p className="text-gray-400 text-sm mb-4">
            Connect with friends to share bar hops and discover new places together.
          </p>

          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full border-ocean-blue text-ocean-blue hover:bg-ocean-blue hover:text-white"
            >
              Find Friends
            </Button>
            <Button
              variant="outline" 
              className="w-full border-gray-600 text-gray-300"
            >
              Friend Requests (0)
            </Button>
            <Button
              variant="outline"
              className="w-full border-gray-600 text-gray-300"
            >
              My Friends (0)
            </Button>
          </div>
        </Card>

        {/* Notifications Section */}
        <Card className="bg-navy-darker p-6 border-navy-darker">
          <div className="flex items-center gap-3 mb-4">
            <Bell className="h-5 w-5 text-vibrant-pink" />
            <h2 className="text-lg font-semibold">Notifications</h2>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Friend Requests</span>
              <div className="w-10 h-6 bg-gray-600 rounded-full"></div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Bar Hop Invites</span>
              <div className="w-10 h-6 bg-vibrant-pink rounded-full"></div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">New Bar Recommendations</span>
              <div className="w-10 h-6 bg-gray-600 rounded-full"></div>
            </div>
          </div>
        </Card>


      </main>
    </div>
  );
}