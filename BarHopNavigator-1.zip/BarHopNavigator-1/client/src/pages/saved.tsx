import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Heart, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BarCard } from "@/components/BarCard";
import { BarModal } from "@/components/BarModal";
import { savedBarApi } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

// Simulated user ID - in a real app this would come from authentication
const USER_ID = "user-1";

export default function SavedPage() {
  const [selectedBar, setSelectedBar] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: savedBars = [], isLoading } = useQuery({
    queryKey: ['/api/saved-bars', USER_ID],
    queryFn: () => savedBarApi.getSavedBars(USER_ID),
  });

  const removeSavedBarMutation = useMutation({
    mutationFn: (barId: number) => savedBarApi.removeSavedBar(USER_ID, barId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/saved-bars', USER_ID] });
      toast({
        title: "Bar Removed",
        description: "Bar removed from your saved list",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove bar",
        variant: "destructive",
      });
    },
  });

  const handleSaveToggle = (barId: number) => {
    removeSavedBarMutation.mutate(barId);
  };

  const handleBarClick = (savedBar: any) => {
    setSelectedBar(savedBar.bar);
    setIsModalOpen(true);
  };

  const handleAddToHop = (bar: any) => {
    toast({
      title: "Feature Coming Soon",
      description: "Bar hop creation will be available soon!",
    });
  };

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      {/* Header */}
      <header className="bg-navy-darker px-4 py-6 sticky top-0 z-40">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="text-vibrant-pink text-xl fill-current" />
            <span className="text-lg font-semibold">Saved Bars</span>
          </div>
          <span className="text-sm text-gray-400">
            {savedBars.length} saved
          </span>
        </div>
      </header>

      <main className="px-4 pb-24">
        {isLoading ? (
          <div className="space-y-4 mt-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-navy-darker rounded-xl overflow-hidden animate-pulse">
                <div className="h-48 bg-gray-600"></div>
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-gray-600 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-600 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-600 rounded w-1/4"></div>
                </div>
              </div>
            ))}
          </div>
        ) : savedBars.length > 0 ? (
          <div className="space-y-4 mt-6">
            {savedBars.map((savedBar: any) => (
              <BarCard
                key={savedBar.id}
                bar={savedBar.bar}
                isSaved={true}
                onSaveToggle={handleSaveToggle}
                onBarClick={() => handleBarClick(savedBar)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Heart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-300 mb-2">No Saved Bars</h3>
            <p className="text-gray-400 mb-6">
              Start exploring and save your favorite bars for quick access later.
            </p>
            <Button 
              className="bg-vibrant-pink hover:bg-vibrant-pink/90 text-white"
              onClick={() => window.location.hash = "#search"}
            >
              Discover Bars
            </Button>
          </div>
        )}
      </main>

      {/* Bar Detail Modal */}
      <BarModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        bar={selectedBar}
        isSaved={true}
        onSaveToggle={handleSaveToggle}
        onAddToHop={handleAddToHop}
      />
    </div>
  );
}
