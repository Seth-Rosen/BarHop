import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, MapPin, Star } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface UserLocation {
  latitude: number;
  longitude: number;
  address?: string;
}

interface Bar {
  place_id: string;
  name: string;
  formatted_address: string;
  rating?: number;
  price_level?: number;
  photos?: string[];
  opening_hours?: {
    open_now: boolean;
  };
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  types: string[];
}

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const { toast } = useToast();

  // Get user's location
  const getUserLocation = () => {
    setIsLoadingLocation(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ latitude, longitude });
          setIsLoadingLocation(false);
          toast({
            title: "Location Found",
            description: "Now searching for bars near you.",
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          setIsLoadingLocation(false);
          toast({
            title: "Location Error",
            description: "Please allow location access or search by area name.",
            variant: "destructive",
          });
        }
      );
    } else {
      setIsLoadingLocation(false);
      toast({
        title: "Location Not Supported",
        description: "Please search by area name instead.",
        variant: "destructive",
      });
    }
  };

  // Search bars using Google Places API directly
  const searchBars = async (): Promise<{ bars: Bar[] }> => {
    if (!searchQuery && !userLocation) {
      throw new Error("Search query or location required");
    }

    const GOOGLE_PLACES_API_KEY = import.meta.env.VITE_GOOGLE_PLACES_API_KEY;
    
    if (!GOOGLE_PLACES_API_KEY) {
      throw new Error("Google Places API key not found");
    }

    if (searchQuery) {
      // Text search for location-based queries like "west loop chicago" or "manhattan new york bars"
      const enhancedQuery = searchQuery.toLowerCase().includes('bar') || 
                           searchQuery.toLowerCase().includes('club') || 
                           searchQuery.toLowerCase().includes('pub') || 
                           searchQuery.toLowerCase().includes('tavern') 
                           ? searchQuery 
                           : `${searchQuery} bars`;

      const requestBody = {
        textQuery: enhancedQuery,
        maxResultCount: 20
      };

      const response = await fetch('https://places.googleapis.com/v1/places:searchText', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY,
          'X-Goog-FieldMask': 'places.displayName,places.formattedAddress,places.rating,places.priceLevel,places.photos,places.location,places.types,places.id,places.currentOpeningHours'
        },
        body: JSON.stringify(requestBody)
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error("Search failed");
      }

      // Transform to match expected format
      const bars = (data.places || []).map((place: any) => ({
        place_id: place.id,
        name: place.displayName?.text || '',
        formatted_address: place.formattedAddress || '',
        rating: place.rating,
        price_level: place.priceLevel,
        geometry: {
          location: {
            lat: place.location?.latitude || 0,
            lng: place.location?.longitude || 0
          }
        },
        types: place.types || [],
        opening_hours: place.currentOpeningHours ? {
          open_now: place.currentOpeningHours.openNow
        } : undefined,
        photos: place.photos?.map((photo: any) => 
          `https://places.googleapis.com/v1/${photo.name}/media?maxWidthPx=400&key=${GOOGLE_PLACES_API_KEY}`
        ) || []
      }));

      // Add distance calculation if user location is available
      if (userLocation) {
        const barsWithDistance = bars.map((bar: any) => {
          const R = 3959; // Earth's radius in miles
          const dLat = (bar.geometry.location.lat - userLocation.latitude) * Math.PI / 180;
          const dLon = (bar.geometry.location.lng - userLocation.longitude) * Math.PI / 180;
          const a = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(userLocation.latitude * Math.PI / 180) * Math.cos(bar.geometry.location.lat * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
          const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
          const distance = R * c * 1609.34; // Convert to meters
          
          return { ...bar, distance };
        }).sort((a: any, b: any) => (a.distance || 0) - (b.distance || 0));
        
        return { bars: barsWithDistance };
      }

      return { bars };
    } else {
      // Nearby search for user location
      const requestBody = {
        includedTypes: ["bar", "night_club"],
        maxResultCount: 20,
        locationRestriction: {
          circle: {
            center: {
              latitude: userLocation.latitude,
              longitude: userLocation.longitude
            },
            radius: 50000 // 50km radius
          }
        }
      };

      const response = await fetch('https://places.googleapis.com/v1/places:searchNearby', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY,
          'X-Goog-FieldMask': 'places.displayName,places.formattedAddress,places.rating,places.priceLevel,places.photos,places.location,places.types,places.id,places.currentOpeningHours'
        },
        body: JSON.stringify(requestBody)
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error("Search failed");
      }

      // Transform and sort by distance
      const bars = (data.places || []).map((place: any) => {
        const R = 3959; // Earth's radius in miles
        const dLat = (place.location.latitude - userLocation.latitude) * Math.PI / 180;
        const dLon = (place.location.longitude - userLocation.longitude) * Math.PI / 180;
        const a = 
          Math.sin(dLat/2) * Math.sin(dLat/2) +
          Math.cos(userLocation.latitude * Math.PI / 180) * Math.cos(place.location.latitude * Math.PI / 180) *
          Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        const distance = R * c * 1609.34; // Convert to meters

        return {
          place_id: place.id,
          name: place.displayName?.text || '',
          formatted_address: place.formattedAddress || '',
          rating: place.rating,
          price_level: place.priceLevel,
          distance: distance,
          geometry: {
            location: {
              lat: place.location?.latitude || 0,
              lng: place.location?.longitude || 0
            }
          },
          types: place.types || [],
          opening_hours: place.currentOpeningHours ? {
            open_now: place.currentOpeningHours.openNow
          } : undefined,
          photos: place.photos?.map((photo: any) => 
            `https://places.googleapis.com/v1/${photo.name}/media?maxWidthPx=400&key=${GOOGLE_PLACES_API_KEY}`
          ) || []
        };
      }).sort((a: any, b: any) => a.distance - b.distance);

      return { bars };
    }
  };

  // Search query
  const {
    data: searchResults,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ["simple-search", searchQuery, userLocation?.latitude, userLocation?.longitude],
    queryFn: searchBars,
    enabled: !!(searchQuery || userLocation), // Allow search with just query or location
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Auto-search when location is found
  useEffect(() => {
    if (userLocation && !searchQuery) {
      refetch();
    }
  }, [userLocation, searchQuery, refetch]);

  const handleSearch = () => {
    if (searchQuery.trim()) {
      refetch();
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const calculateDistance = (bar: Bar): string => {
    if (!userLocation || !(bar as any).distance) return "";
    
    // Convert meters to miles and format (distance is already calculated in searchBars function)
    const distanceInMiles = (bar as any).distance / 1609.34;
    
    return distanceInMiles < 1 
      ? `${(distanceInMiles * 5280).toFixed(0)} ft`
      : `${distanceInMiles.toFixed(1)} mi`;
  };

  const bars = searchResults?.bars || [];

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-4">Find Bars Near You</h1>
        
        {/* Search Input */}
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search for bars, clubs, or enter area name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              className="pl-10"
            />
          </div>
          <Button onClick={handleSearch} disabled={!searchQuery.trim()}>
            Search
          </Button>
        </div>

        {/* Location Button */}
        <Button 
          onClick={getUserLocation} 
          disabled={isLoadingLocation}
          variant="outline"
          className="w-full"
        >
          <MapPin className="h-4 w-4 mr-2" />
          {isLoadingLocation ? "Getting Location..." : "Find Bars Near Me"}
        </Button>

        {userLocation && (
          <p className="text-sm text-gray-600 mt-2">
            📍 Using your current location
          </p>
        )}

        {/* Browse by Category Section */}
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-4">Browse by Category</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { name: "Cocktail Bars", icon: "🍸", search: "cocktail bars" },
              { name: "Sports Bars", icon: "🏈", search: "sports bars" },
              { name: "Nightclubs", icon: "🎭", search: "nightclubs" },
              { name: "Dive Bars", icon: "🍺", search: "dive bars" },
              { name: "Wine Bars", icon: "🍷", search: "wine bars" },
              { name: "Rooftop Bars", icon: "🏙️", search: "rooftop bars" },
              { name: "Live Music", icon: "🎵", search: "live music bars" },
              { name: "Happy Hour", icon: "⏰", search: "happy hour bars" }
            ].map((category) => (
              <Card 
                key={category.name} 
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => {
                  setSearchQuery(category.search);
                  setTimeout(() => refetch(), 100);
                }}
              >
                <CardContent className="p-3 text-center">
                  <div className="text-2xl mb-1">{category.icon}</div>
                  <h4 className="font-medium text-xs">{category.name}</h4>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="text-center py-8">
          <p>Searching for bars...</p>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="text-center py-8 text-red-600">
          <p>Search failed. Please try again.</p>
        </div>
      )}

      {/* Results */}
      {bars.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">
            Found {bars.length} bars
          </h2>
          
          {bars.map((bar) => (
            <Card key={bar.place_id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{bar.name}</h3>
                    <p className="text-gray-600 text-sm mb-2">{bar.formatted_address}</p>
                    
                    <div className="flex items-center gap-2 mb-2">
                      {bar.rating && (
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{bar.rating}</span>
                        </div>
                      )}
                      
                      {bar.price_level && (
                        <Badge variant="outline">
                          {"$".repeat(bar.price_level)}
                        </Badge>
                      )}
                      
                      {bar.opening_hours?.open_now && (
                        <Badge variant="default" className="bg-green-500">
                          Open Now
                        </Badge>
                      )}
                      
                      {userLocation && (
                        <Badge variant="secondary">
                          {calculateDistance(bar)}
                        </Badge>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {bar.types
                        .filter(type => !['establishment', 'point_of_interest'].includes(type))
                        .slice(0, 3)
                        .map((type) => (
                          <Badge key={type} variant="outline" className="text-xs">
                            {type.replace(/_/g, ' ')}
                          </Badge>
                        ))}
                    </div>
                  </div>
                  
                  {bar.photos && bar.photos[0] && (
                    <img 
                      src={bar.photos[0]} 
                      alt={bar.name}
                      className="w-20 h-20 object-cover rounded ml-4"
                    />
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* No Results */}
      {!isLoading && bars.length === 0 && (searchQuery || userLocation) && (
        <div className="text-center py-8">
          <p className="text-gray-600">No bars found. Try a different search or location.</p>
        </div>
      )}
    </div>
  );
}