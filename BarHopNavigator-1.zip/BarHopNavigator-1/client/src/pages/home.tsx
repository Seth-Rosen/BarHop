import { useQuery } from "@tanstack/react-query";
import { MapPin, Star, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface FeaturedBar {
  place_id: string;
  name: string;
  formatted_address: string;
  rating?: number;
  price_level?: number;
  photos?: string[];
  opening_hours?: {
    open_now: boolean;
  };
  types: string[];
}

export default function HomePage() {
  // Get featured bars using Google Places API directly
  const { data: featuredData, isLoading } = useQuery({
    queryKey: ["featured-bars"],
    queryFn: async () => {
      // Use Chicago coordinates as center
      const center = new google.maps.LatLng(41.8781, -87.6298);
      const request = {
        fields: ["displayName", "location", "businessStatus", "rating", "priceLevel", "formattedAddress", "photos", "types"],
        locationRestriction: {
          center: center,
          radius: 10000, // 10km radius
        },
        includedPrimaryTypes: ["bar", "night_club"],
        maxResultCount: 20,
        rankPreference: google.maps.places.SearchNearbyRankPreference.POPULARITY,
        language: "en-US",
        region: "us",
      };
      
      //@ts-ignore
      const { places } = await google.maps.places.Place.searchNearby(request);
      
      // Transform to match expected format and randomly select 5
      const allBars = places.map((place: any) => ({
        place_id: place.id,
        name: place.displayName?.text || '',
        formatted_address: place.formattedAddress || '',
        rating: place.rating,
        price_level: place.priceLevel,
        photos: place.photos?.map((photo: any) => photo.getURI()) || [],
        opening_hours: place.businessStatus === 'OPERATIONAL' ? { open_now: true } : undefined,
        types: place.types || []
      }));
      
      // Randomly shuffle and select 5 bars
      const shuffled = allBars.sort(() => 0.5 - Math.random());
      const randomBars = shuffled.slice(0, 5);
      
      return { bars: randomBars };
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const featuredBars = featuredData?.bars || [];

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      {/* Hero Section */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-4">Plan the Perfect Night Out</h1>
        <p className="text-xl text-gray-600 mb-6">
          Discover amazing bars and create your very own bar hop with friends - from craft cocktails to dive bars
        </p>
      </div>

      {/* Featured Bars & Clubs Section */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Featured Bars & Clubs</h2>
          <Link href="/search">
            <Button variant="ghost">View All →</Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {[...Array(5)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-32 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {featuredBars.map((bar: FeaturedBar) => (
              <Card key={bar.place_id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                <div className="relative">
                  {bar.photos && bar.photos[0] ? (
                    <img 
                      src={bar.photos[0]} 
                      alt={bar.name}
                      className="w-full h-48 object-cover"
                    />
                  ) : (
                    <div className="w-full h-48 bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
                      <span className="text-white text-2xl font-bold">
                        {bar.name.split(' ').map(w => w[0]).join('').slice(0, 2)}
                      </span>
                    </div>
                  )}
                  
                  {bar.opening_hours?.open_now && (
                    <Badge className="absolute top-2 right-2 bg-green-500">
                      <Clock className="h-3 w-3 mr-1" />
                      Open Now
                    </Badge>
                  )}
                </div>
                
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-2 line-clamp-1">{bar.name}</h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{bar.formatted_address}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {bar.rating && (
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{bar.rating}</span>
                        </div>
                      )}
                      
                      {bar.price_level && (
                        <Badge variant="outline">
                          {"$".repeat(bar.price_level)}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {bar.types
                        .filter(type => ['bar', 'night_club', 'restaurant'].includes(type))
                        .slice(0, 1)
                        .map((type) => (
                          <Badge key={type} variant="secondary" className="text-xs">
                            {type === 'night_club' ? 'Club' : type}
                          </Badge>
                        ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>



    </div>
  );
}