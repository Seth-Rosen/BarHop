import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const bars = pgTable("bars", {
  id: serial("id").primaryKey(),
  placeId: text("place_id").notNull().unique(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  rating: real("rating"),
  priceLevel: integer("price_level"),
  phoneNumber: text("phone_number"),
  website: text("website"),
  photos: jsonb("photos").$type<string[]>().default([]),
  openingHours: jsonb("opening_hours").$type<{
    periods: Array<{
      open: { day: number; time: string };
      close?: { day: number; time: string };
    }>;
    weekdayText: string[];
  }>(),
  isOpenNow: boolean("is_open_now"),
  categories: text("categories").array().default([]),
  reviews: jsonb("reviews").$type<Array<{
    author: string;
    rating: number;
    text: string;
    time: string;
  }>>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const savedBars = pgTable("saved_bars", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  barId: integer("bar_id").references(() => bars.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Session storage table.
export const sessions = pgTable(
  "sessions",
  {
    sid: text("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  }
);

// User storage table.
export const users = pgTable("users", {
  id: text("id").primaryKey().notNull(),
  email: text("email").unique(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  profileImageUrl: text("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Friends table for friend relationships
export const friends = pgTable("friends", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id).notNull(),
  friendId: text("friend_id").references(() => users.id).notNull(),
  status: text("status").notNull().default("pending"), // pending, accepted, blocked
  createdAt: timestamp("created_at").defaultNow(),
});

export const barHops = pgTable("bar_hops", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: text("user_id").references(() => users.id).notNull(),
  barIds: integer("bar_ids").array().default([]),
  isPublic: boolean("is_public").default(false),
  invitedUserIds: text("invited_user_ids").array().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertBarSchema = createInsertSchema(bars).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSavedBarSchema = createInsertSchema(savedBars).omit({
  id: true,
  createdAt: true,
});

export const insertBarHopSchema = createInsertSchema(barHops).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFriendSchema = createInsertSchema(friends).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertBar = z.infer<typeof insertBarSchema>;
export type Bar = typeof bars.$inferSelect;
export type InsertSavedBar = z.infer<typeof insertSavedBarSchema>;
export type SavedBar = typeof savedBars.$inferSelect;
export type InsertBarHop = z.infer<typeof insertBarHopSchema>;
export type BarHop = typeof barHops.$inferSelect;
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;
export type Friend = typeof friends.$inferSelect;
export type InsertFriend = z.infer<typeof insertFriendSchema>;
