import { bars, savedBars, barHops, users, friends, type Bar, type InsertBar, type SavedBar, type InsertSavedBar, type BarHop, type InsertBarHop, type User, type UpsertUser, type Friend, type InsertFriend } from "@shared/schema";
import { db } from "./db";
import { eq, and, or } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  searchUsers(query: string): Promise<User[]>;
  
  // Friend operations
  getFriend(userId: string, friendId: string): Promise<Friend | undefined>;
  getFriendsByUser(userId: string): Promise<Friend[]>;
  getFriendRequests(userId: string): Promise<Friend[]>;
  createFriendRequest(friend: InsertFriend): Promise<Friend>;
  updateFriendStatus(userId: string, friendId: string, status: string): Promise<Friend | undefined>;
  deleteFriend(userId: string, friendId: string): Promise<boolean>;
  
  // Bar operations
  getBar(id: number): Promise<Bar | undefined>;
  getBarByPlaceId(placeId: string): Promise<Bar | undefined>;
  createBar(bar: InsertBar): Promise<Bar>;
  updateBar(id: number, bar: Partial<InsertBar>): Promise<Bar | undefined>;
  searchBars(query: string): Promise<Bar[]>;
  getBarsNearLocation(latitude: number, longitude: number, radius: number): Promise<Bar[]>;
  
  // Saved bars operations
  getSavedBar(userId: string, barId: number): Promise<SavedBar | undefined>;
  getSavedBarsByUser(userId: string): Promise<SavedBar[]>;
  createSavedBar(savedBar: InsertSavedBar): Promise<SavedBar>;
  deleteSavedBar(userId: string, barId: number): Promise<boolean>;
  
  // Bar hops operations
  getBarHop(id: number): Promise<BarHop | undefined>;
  getBarHopsByUser(userId: string): Promise<BarHop[]>;
  createBarHop(barHop: InsertBarHop): Promise<BarHop>;
  updateBarHop(id: number, barHop: Partial<InsertBarHop>): Promise<BarHop | undefined>;
  deleteBarHop(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async searchUsers(query: string): Promise<User[]> {
    const allUsers = await db.select().from(users);
    const lowercaseQuery = query.toLowerCase();
    return allUsers.filter(user =>
      (user.firstName && user.firstName.toLowerCase().includes(lowercaseQuery)) ||
      (user.lastName && user.lastName.toLowerCase().includes(lowercaseQuery)) ||
      (user.email && user.email.toLowerCase().includes(lowercaseQuery))
    );
  }

  // Friend operations
  async getFriend(userId: string, friendId: string): Promise<Friend | undefined> {
    const [friend] = await db.select().from(friends).where(
      and(eq(friends.userId, userId), eq(friends.friendId, friendId))
    );
    return friend || undefined;
  }

  async getFriendsByUser(userId: string): Promise<Friend[]> {
    return await db.select().from(friends).where(
      and(eq(friends.userId, userId), eq(friends.status, "accepted"))
    );
  }

  async getFriendRequests(userId: string): Promise<Friend[]> {
    return await db.select().from(friends).where(
      and(eq(friends.friendId, userId), eq(friends.status, "pending"))
    );
  }

  async createFriendRequest(friend: InsertFriend): Promise<Friend> {
    const [newFriend] = await db
      .insert(friends)
      .values(friend)
      .returning();
    return newFriend;
  }

  async updateFriendStatus(userId: string, friendId: string, status: string): Promise<Friend | undefined> {
    const [friend] = await db
      .update(friends)
      .set({ status })
      .where(and(eq(friends.userId, friendId), eq(friends.friendId, userId)))
      .returning();
    return friend || undefined;
  }

  async deleteFriend(userId: string, friendId: string): Promise<boolean> {
    const result = await db
      .delete(friends)
      .where(
        or(
          and(eq(friends.userId, userId), eq(friends.friendId, friendId)),
          and(eq(friends.userId, friendId), eq(friends.friendId, userId))
        )
      );
    return (result.rowCount || 0) > 0;
  }

  // Bar operations
  async getBar(id: number): Promise<Bar | undefined> {
    const [bar] = await db.select().from(bars).where(eq(bars.id, id));
    return bar || undefined;
  }

  async getBarByPlaceId(placeId: string): Promise<Bar | undefined> {
    const [bar] = await db.select().from(bars).where(eq(bars.placeId, placeId));
    return bar || undefined;
  }

  async createBar(insertBar: InsertBar): Promise<Bar> {
    const [bar] = await db
      .insert(bars)
      .values(insertBar)
      .returning();
    return bar;
  }

  async updateBar(id: number, updateData: Partial<InsertBar>): Promise<Bar | undefined> {
    const [bar] = await db
      .update(bars)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(bars.id, id))
      .returning();
    return bar || undefined;
  }

  async searchBars(query: string): Promise<Bar[]> {
    const allBars = await db.select().from(bars);
    const lowercaseQuery = query.toLowerCase();
    return allBars.filter(bar =>
      bar.name.toLowerCase().includes(lowercaseQuery) ||
      bar.address.toLowerCase().includes(lowercaseQuery) ||
      (bar.categories && bar.categories.some(category => category.toLowerCase().includes(lowercaseQuery)))
    );
  }

  async getBarsNearLocation(latitude: number, longitude: number, radius: number): Promise<Bar[]> {
    const allBars = await db.select().from(bars);
    return allBars.filter(bar => {
      const distance = this.calculateDistance(latitude, longitude, bar.latitude, bar.longitude);
      return distance <= radius;
    });
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 3959; // Earth's radius in miles
    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRad(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  // Saved bars operations
  async getSavedBar(userId: string, barId: number): Promise<SavedBar | undefined> {
    const [savedBar] = await db.select().from(savedBars).where(
      and(eq(savedBars.userId, userId), eq(savedBars.barId, barId))
    );
    return savedBar || undefined;
  }

  async getSavedBarsByUser(userId: string): Promise<SavedBar[]> {
    return await db.select().from(savedBars).where(eq(savedBars.userId, userId));
  }

  async createSavedBar(insertSavedBar: InsertSavedBar): Promise<SavedBar> {
    const [savedBar] = await db
      .insert(savedBars)
      .values(insertSavedBar)
      .returning();
    return savedBar;
  }

  async deleteSavedBar(userId: string, barId: number): Promise<boolean> {
    const result = await db
      .delete(savedBars)
      .where(and(eq(savedBars.userId, userId), eq(savedBars.barId, barId)));
    return (result.rowCount || 0) > 0;
  }

  // Bar hops operations
  async getBarHop(id: number): Promise<BarHop | undefined> {
    const [barHop] = await db.select().from(barHops).where(eq(barHops.id, id));
    return barHop || undefined;
  }

  async getBarHopsByUser(userId: string): Promise<BarHop[]> {
    return await db.select().from(barHops).where(eq(barHops.userId, userId));
  }

  async createBarHop(insertBarHop: InsertBarHop): Promise<BarHop> {
    const [barHop] = await db
      .insert(barHops)
      .values(insertBarHop)
      .returning();
    return barHop;
  }

  async updateBarHop(id: number, updateData: Partial<InsertBarHop>): Promise<BarHop | undefined> {
    const [barHop] = await db
      .update(barHops)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(barHops.id, id))
      .returning();
    return barHop || undefined;
  }

  async deleteBarHop(id: number): Promise<boolean> {
    const result = await db.delete(barHops).where(eq(barHops.id, id));
    return (result.rowCount || 0) > 0;
  }
}

export const storage = new DatabaseStorage();
