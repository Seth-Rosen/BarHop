import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBarSchema, insertSavedBarSchema, insertBarHopSchema, insertFriendSchema } from "@shared/schema";
import { setupAuth, isAuthenticated } from "./replitAuth";

const GOOGLE_PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY;

if (!GOOGLE_PLACES_API_KEY) {
  throw new Error("GOOGLE_PLACES_API_KEY environment variable is required");
}

interface GooglePlaceResult {
  place_id: string;
  name: string;
  formatted_address: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  rating?: number;
  price_level?: number;
  formatted_phone_number?: string;
  website?: string;
  photos?: Array<{
    photo_reference: string;
    width: number;
    height: number;
  }>;
  opening_hours?: {
    open_now: boolean;
    periods: Array<{
      open: { day: number; time: string };
      close?: { day: number; time: string };
    }>;
    weekday_text: string[];
  };
  types: string[];
  reviews?: Array<{
    author_name: string;
    rating: number;
    text: string;
    time: number;
  }>;
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Simple search endpoint using your working API approach
  app.get("/api/bars/simple-search", async (req, res) => {
    try {
      const { query, lat, lng, radius = 5000 } = req.query;
      
      if (!query && (!lat || !lng)) {
        return res.status(400).json({ error: "Either query or coordinates required" });
      }

      const GOOGLE_PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY;

      if (lat && lng) {
        // Use your working nearby search approach
        const requestBody = {
          includedTypes: ["bar", "night_club", "restaurant"],
          maxResultCount: 20,
          locationRestriction: {
            circle: {
              center: {
                latitude: parseFloat(lat.toString()),
                longitude: parseFloat(lng.toString())
              },
              radius: parseFloat(radius.toString())
            }
          }
        };

        const response = await fetch('https://places.googleapis.com/v1/places:searchNearby', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY!,
            'X-Goog-FieldMask': 'places.displayName,places.formattedAddress,places.rating,places.priceLevel,places.photos,places.location,places.types,places.id,places.currentOpeningHours'
          },
          body: JSON.stringify(requestBody)
        });

        const data = await response.json();
        
        if (!response.ok) {
          console.error("Google Places API error:", data);
          return res.status(500).json({ error: "Search failed", details: data });
        }

        // Transform to match your format
        const bars = (data.places || [])
          .filter((place: any) => 
            place.types?.some((type: string) => 
              ['bar', 'night_club', 'restaurant'].includes(type)
            )
          )
          .map((place: any) => ({
            place_id: place.id,
            name: place.displayName?.text || '',
            formatted_address: place.formattedAddress || '',
            rating: place.rating,
            price_level: place.priceLevel,
            geometry: {
              location: {
                lat: place.location?.latitude || 0,
                lng: place.location?.longitude || 0
              }
            },
            types: place.types || [],
            opening_hours: place.currentOpeningHours ? {
              open_now: place.currentOpeningHours.openNow
            } : undefined,
            photos: place.photos?.map((photo: any) => 
              `https://places.googleapis.com/v1/${photo.name}/media?maxWidthPx=400&key=${GOOGLE_PLACES_API_KEY}`
            ) || []
          }));

        res.json({ bars });
      } else {
        // Use text search for query-based searches
        const searchQuery = query?.toString() || "";
        const enhancedQuery = searchQuery.toLowerCase().includes('bar') || 
                             searchQuery.toLowerCase().includes('club') || 
                             searchQuery.toLowerCase().includes('pub') || 
                             searchQuery.toLowerCase().includes('tavern') 
                             ? searchQuery 
                             : `${searchQuery} bars`;

        const requestBody = {
          textQuery: enhancedQuery,
          maxResultCount: 20
        };

        const response = await fetch('https://places.googleapis.com/v1/places:searchText', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY!,
            'X-Goog-FieldMask': 'places.displayName,places.formattedAddress,places.rating,places.priceLevel,places.photos,places.location,places.types,places.id,places.currentOpeningHours'
          },
          body: JSON.stringify(requestBody)
        });

        const data = await response.json();
        
        if (!response.ok) {
          console.error("Google Places API error:", data);
          return res.status(500).json({ error: "Search failed", details: data });
        }

        // Transform to match your format
        const bars = (data.places || []).map((place: any) => ({
          place_id: place.id,
          name: place.displayName?.text || '',
          formatted_address: place.formattedAddress || '',
          rating: place.rating,
          price_level: place.priceLevel,
          geometry: {
            location: {
              lat: place.location?.latitude || 0,
              lng: place.location?.longitude || 0
            }
          },
          types: place.types || [],
          opening_hours: place.currentOpeningHours ? {
            open_now: place.currentOpeningHours.openNow
          } : undefined,
          photos: place.photos?.map((photo: any) => 
            `https://places.googleapis.com/v1/${photo.name}/media?maxWidthPx=400&key=${GOOGLE_PLACES_API_KEY}`
          ) || []
        }));

        res.json({ bars });
      }
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Search bars using Google Places API
  app.get("/api/bars/search", async (req, res) => {
    try {
      const { query, location, latitude, longitude, radius = 3000 } = req.query;
      
      if (!query && !location && !latitude && !longitude) {
        return res.status(400).json({ error: "Either query or location coordinates are required" });
      }

      let url: string;
      let searchQuery = query?.toString() || "";

      let enhancedQuery;
      
      if (latitude && longitude) {
        // Use nearby search for precise coordinate-based location
        const params = new URLSearchParams({
          key: GOOGLE_PLACES_API_KEY!,
          location: `${latitude},${longitude}`,
          radius: radius.toString(),
          type: "bar"
        });
        
        url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?${params.toString()}`;
      } else if (query || location) {
        // Use text search for queries or address-based location searches
        if (query) {
          enhancedQuery = searchQuery.toLowerCase().includes('bar') || 
                         searchQuery.toLowerCase().includes('club') || 
                         searchQuery.toLowerCase().includes('pub') || 
                         searchQuery.toLowerCase().includes('tavern') 
                         ? searchQuery 
                         : `${searchQuery} bars`;
        } else if (location) {
          enhancedQuery = `bars near ${location}`;
        }
        
        const params = new URLSearchParams();
        params.append('key', GOOGLE_PLACES_API_KEY!);
        if (enhancedQuery) {
          params.append('query', enhancedQuery);
        }
        
        url = `https://maps.googleapis.com/maps/api/place/textsearch/json?${params.toString()}`;
      } else {
        // Use multiple searches to catch all venues
        const searches = [];
        
        // Search 1: General bars
        const barParams = new URLSearchParams({
          key: GOOGLE_PLACES_API_KEY!,
          type: "bar",
          radius: radius.toString(),
        });
        
        if (latitude && longitude) {
          const locationStr = `${latitude},${longitude}`;
          barParams.append("location", locationStr);
          console.log("Searching near coordinates:", locationStr, "within radius:", radius, "meters");
        }
        
        searches.push(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?${barParams.toString()}`);
        
        // Search 2: Night clubs
        const clubParams = new URLSearchParams({
          key: GOOGLE_PLACES_API_KEY!,
          type: "night_club",
          radius: radius.toString(),
        });
        
        if (location) {
          clubParams.append("location", location.toString());
        }
        
        searches.push(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?${clubParams.toString()}`);
        
        // Search 3: General establishment search with bar/pub keywords
        const keywordParams = new URLSearchParams({
          key: GOOGLE_PLACES_API_KEY!,
          type: "establishment",
          radius: radius.toString(),
          keyword: "bar pub tavern cocktail lounge",
        });
        
        if (location) {
          keywordParams.append("location", location.toString());
        }
        
        searches.push(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?${keywordParams.toString()}`);
        
        // Execute all searches and combine results
        const allResults = [];
        const seenPlaceIds = new Set();
        
        for (const searchUrl of searches) {
          try {
            console.log("Fetching from URL:", searchUrl);
            const response = await fetch(searchUrl);
            const data = await response.json();
            console.log(`Search returned ${data.results?.length || 0} results with status:`, data.status);
            
            if (data.status === "OK" && data.results) {
              for (const place of data.results) {
                // Filter out liquor stores, gas stations, and non-bar establishments
                const isLiquorStore = place.types && place.types.some((type: string) => 
                  type.includes('liquor_store') || 
                  type.includes('gas_station') || 
                  type.includes('convenience_store') ||
                  type.includes('grocery_or_supermarket') ||
                  type.includes('store')
                );
                
                // Also filter by name to catch liquor stores
                const hasLiquorInName = place.name && (
                  place.name.toLowerCase().includes('liquor') ||
                  place.name.toLowerCase().includes('wine shop') ||
                  place.name.toLowerCase().includes('package store') ||
                  place.name.toLowerCase().includes('bottle shop')
                );
                
                if (!seenPlaceIds.has(place.place_id) && !isLiquorStore && !hasLiquorInName) {
                  seenPlaceIds.add(place.place_id);
                  allResults.push(place);
                }
              }
            }
          } catch (error) {
            console.error("Error in search:", error);
          }
        }
        
        // Use the combined results
        const combinedData = {
          results: allResults,
          status: "OK"
        };
        
        console.log(`Combined search found ${allResults.length} unique venues`);
        
        // Process combined results
        const bars = await Promise.all(
          combinedData.results.map(async (place: GooglePlaceResult) => {
            // Check if bar already exists in our database
            let existingBar = await storage.getBarByPlaceId(place.place_id);
            
            if (existingBar) {
              return existingBar;
            }

            // Get detailed place information
            const detailsResponse = await fetch(
              `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&key=${GOOGLE_PLACES_API_KEY}&fields=name,formatted_address,geometry,rating,price_level,formatted_phone_number,website,photos,opening_hours,types,reviews`
            );
            const detailsData = await detailsResponse.json();
            const details = detailsData.result;

            // Create comprehensive bar object
            const barData = {
              placeId: place.place_id,
              name: details.name || place.name,
              address: details.formatted_address || place.formatted_address,
              latitude: details.geometry?.location?.lat || place.geometry.location.lat,
              longitude: details.geometry?.location?.lng || place.geometry.location.lng,
              rating: details.rating || place.rating,
              priceLevel: details.price_level || place.price_level,
              phoneNumber: details.formatted_phone_number,
              website: details.website,
              photos: details.photos?.map((photo: any) => 
                `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${photo.photo_reference}&key=${GOOGLE_PLACES_API_KEY}`
              ) || [],
              categories: details.types || place.types || [],
              isOpenNow: details.opening_hours?.open_now,
              openingHours: details.opening_hours?.weekday_text || [],
              reviews: details.reviews || []
            };

            // Save to database
            try {
              const savedBar = await storage.createBar(barData);
              return savedBar;
            } catch (error) {
              console.error("Error saving bar:", error);
              return barData;
            }
          })
        );

        return res.json({
          bars: bars.filter(Boolean),
          status: "OK"
        });
      }

      console.log("Fetching from URL:", url);
      console.log("Query being sent to Google Places:", enhancedQuery || "multiple searches");
      const response = await fetch(url);
      const data = await response.json();
      console.log("Google Places API response status:", data.status);
      console.log("Number of results:", data.results?.length || 0);

      if (data.status !== "OK" && data.status !== "ZERO_RESULTS") {
        console.error("Google Places API error:", data);
        return res.status(500).json({ error: "Failed to search bars", details: data });
      }

      // Transform Google Places results to our bar format
      const bars = await Promise.all(
        data.results.map(async (place: GooglePlaceResult) => {
          // Check if bar already exists in our database
          let existingBar = await storage.getBarByPlaceId(place.place_id);
          
          if (existingBar) {
            return existingBar;
          }

          // Get detailed place information
          const detailsResponse = await fetch(
            `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&key=${GOOGLE_PLACES_API_KEY}&fields=name,formatted_address,geometry,rating,price_level,formatted_phone_number,website,photos,opening_hours,types,reviews`
          );
          const detailsData = await detailsResponse.json();
          const details = detailsData.result;

          // Create new bar entry
          const newBar = await storage.createBar({
            placeId: place.place_id,
            name: details.name || place.name,
            address: details.formatted_address || place.formatted_address,
            latitude: details.geometry?.location?.lat || place.geometry.location.lat,
            longitude: details.geometry?.location?.lng || place.geometry.location.lng,
            rating: details.rating,
            priceLevel: details.price_level,
            phoneNumber: details.formatted_phone_number,
            website: details.website,
            photos: details.photos?.map((photo: any) => 
              `https://maps.googleapis.com/maps/api/place/photo?maxwidth=800&photo_reference=${photo.photo_reference}&key=${GOOGLE_PLACES_API_KEY}`
            ) || [],
            openingHours: details.opening_hours ? {
              periods: details.opening_hours.periods || [],
              weekdayText: details.opening_hours.weekday_text || []
            } : undefined,
            isOpenNow: details.opening_hours?.open_now,
            categories: details.types?.filter((type: string) => 
              !["establishment", "point_of_interest"].includes(type)
            ) || [],
            reviews: details.reviews?.slice(0, 5).map((review: any) => ({
              author: review.author_name,
              rating: review.rating,
              text: review.text,
              time: new Date(review.time * 1000).toISOString()
            })) || []
          });

          return newBar;
        })
      );

      res.json({ bars, status: data.status });
    } catch (error) {
      console.error("Search bars error:", error);
      res.status(500).json({ error: "Failed to search bars" });
    }
  });

  // Get featured bars for home screen using working API approach - defaults to Chicago
  app.get("/api/bars/featured", async (req, res) => {
    try {
      const GOOGLE_PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY;
      
      // Default to Chicago for this example
      const requestBody = {
        textQuery: "popular bars clubs Chicago",
        maxResultCount: 15
      };

      const response = await fetch('https://places.googleapis.com/v1/places:searchText', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY!,
          'X-Goog-FieldMask': 'places.displayName,places.formattedAddress,places.rating,places.priceLevel,places.photos,places.location,places.types,places.id,places.currentOpeningHours'
        },
        body: JSON.stringify(requestBody)
      });

      const data = await response.json();
      
      if (!response.ok) {
        console.error("Google Places API error:", data);
        return res.status(500).json({ error: "Failed to get featured bars" });
      }
      
      // Transform to match your format
      const bars = (data.places || []).map((place: any) => ({
        place_id: place.id,
        name: place.displayName?.text || '',
        formatted_address: place.formattedAddress || '',
        rating: place.rating,
        price_level: place.priceLevel,
        geometry: {
          location: {
            lat: place.location?.latitude || 0,
            lng: place.location?.longitude || 0
          }
        },
        types: place.types || [],
        opening_hours: place.currentOpeningHours ? {
          open_now: place.currentOpeningHours.openNow
        } : undefined,
        photos: place.photos?.map((photo: any) => 
          `https://places.googleapis.com/v1/${photo.name}/media?maxWidthPx=400&key=${GOOGLE_PLACES_API_KEY}`
        ) || []
      }));
      
      res.json({ bars: bars.slice(0, 12) });
    } catch (error) {
      console.error("Get featured bars error:", error);
      res.status(500).json({ error: "Failed to get featured bars" });
    }
  });

  // Save a bar
  app.post("/api/saved-bars", async (req, res) => {
    try {
      const validatedData = insertSavedBarSchema.parse(req.body);
      
      // Check if already saved
      const existing = await storage.getSavedBar(validatedData.userId, validatedData.barId);
      if (existing) {
        return res.status(409).json({ error: "Bar already saved" });
      }

      const savedBar = await storage.createSavedBar(validatedData);
      res.json(savedBar);
    } catch (error) {
      console.error("Save bar error:", error);
      res.status(500).json({ error: "Failed to save bar" });
    }
  });

  // Remove saved bar
  app.delete("/api/saved-bars/:userId/:barId", async (req, res) => {
    try {
      const { userId, barId } = req.params;
      const success = await storage.deleteSavedBar(userId, parseInt(barId));
      
      if (!success) {
        return res.status(404).json({ error: "Saved bar not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Remove saved bar error:", error);
      res.status(500).json({ error: "Failed to remove saved bar" });
    }
  });

  // Get saved bars for user
  app.get("/api/saved-bars/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const savedBars = await storage.getSavedBarsByUser(userId);
      
      // Get full bar details
      const barsWithDetails = await Promise.all(
        savedBars.map(async (savedBar) => {
          const bar = await storage.getBar(savedBar.barId);
          return { ...savedBar, bar };
        })
      );

      res.json(barsWithDetails);
    } catch (error) {
      console.error("Get saved bars error:", error);
      res.status(500).json({ error: "Failed to get saved bars" });
    }
  });

  // Create bar hop
  app.post("/api/bar-hops", async (req, res) => {
    try {
      const validatedData = insertBarHopSchema.parse(req.body);
      const barHop = await storage.createBarHop(validatedData);
      res.json(barHop);
    } catch (error) {
      console.error("Create bar hop error:", error);
      res.status(500).json({ error: "Failed to create bar hop" });
    }
  });

  // Get bar hops for user
  app.get("/api/bar-hops/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const barHops = await storage.getBarHopsByUser(userId);
      
      // Get full bar details for each hop
      const barHopsWithDetails = await Promise.all(
        barHops.map(async (barHop) => {
          const bars = await Promise.all(
            barHop.barIds.map(barId => storage.getBar(barId))
          );
          return { ...barHop, bars: bars.filter(Boolean) };
        })
      );

      res.json(barHopsWithDetails);
    } catch (error) {
      console.error("Get bar hops error:", error);
      res.status(500).json({ error: "Failed to get bar hops" });
    }
  });

  // Update bar hop
  app.put("/api/bar-hops/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertBarHopSchema.partial().parse(req.body);
      
      const barHop = await storage.updateBarHop(id, validatedData);
      if (!barHop) {
        return res.status(404).json({ error: "Bar hop not found" });
      }

      res.json(barHop);
    } catch (error) {
      console.error("Update bar hop error:", error);
      res.status(500).json({ error: "Failed to update bar hop" });
    }
  });

  // Delete bar hop
  app.delete("/api/bar-hops/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteBarHop(id);
      
      if (!success) {
        return res.status(404).json({ error: "Bar hop not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Delete bar hop error:", error);
      res.status(500).json({ error: "Failed to delete bar hop" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
