import { apiRequest } from "@/lib/queryClient";

export const barApi = {
  searchBars: async (query?: string, location?: string, latitude?: number, longitude?: number, radius?: number) => {
    const params = new URLSearchParams();
    if (query) params.append('query', query);
    if (location) params.append('location', location);
    if (latitude) params.append('latitude', latitude.toString());
    if (longitude) params.append('longitude', longitude.toString());
    if (radius) params.append('radius', radius.toString());
    
    const response = await apiRequest('GET', `/api/bars/search?${params.toString()}`);
    return response.json();
  },

  getBar: async (id: number) => {
    const response = await apiRequest('GET', `/api/bars/${id}`);
    return response.json();
  },

  getNearbyBars: async (lat: number, lng: number, radius?: number) => {
    const params = new URLSearchParams({
      lat: lat.toString(),
      lng: lng.toString(),
    });
    if (radius) params.append('radius', radius.toString());
    
    const response = await apiRequest('GET', `/api/bars/nearby?${params.toString()}`);
    return response.json();
  },
};

export const savedBarApi = {
  saveBar: async (userId: string, barId: number) => {
    const response = await apiRequest('POST', '/api/saved-bars', { userId, barId });
    return response.json();
  },

  removeSavedBar: async (userId: string, barId: number) => {
    const response = await apiRequest('DELETE', `/api/saved-bars/${userId}/${barId}`);
    return response.json();
  },

  getSavedBars: async (userId: string) => {
    const response = await apiRequest('GET', `/api/saved-bars/${userId}`);
    return response.json();
  },
};

export const barHopApi = {
  createBarHop: async (name: string, userId: string, barIds: number[] = []) => {
    const response = await apiRequest('POST', '/api/bar-hops', { name, userId, barIds });
    return response.json();
  },

  getBarHops: async (userId: string) => {
    const response = await apiRequest('GET', `/api/bar-hops/${userId}`);
    return response.json();
  },

  updateBarHop: async (id: number, data: { name?: string; barIds?: number[] }) => {
    const response = await apiRequest('PUT', `/api/bar-hops/${id}`, data);
    return response.json();
  },

  deleteBarHop: async (id: number) => {
    const response = await apiRequest('DELETE', `/api/bar-hops/${id}`);
    return response.json();
  },
};
