export interface GoogleMapsLocation {
  lat: number;
  lng: number;
}

export interface UserLocation {
  latitude: number;
  longitude: number;
  address?: string;
}

export interface SearchFilters {
  category?: string;
  openNow?: boolean;
  radius?: number;
  priceLevel?: number;
}

export interface BarSearchResult {
  bars: any[];
  status: string;
}

export interface SavedBarWithDetails {
  id: number;
  userId: string;
  barId: number;
  createdAt: Date;
  bar: any;
}

export interface BarHopWithDetails {
  id: number;
  name: string;
  userId: string;
  barIds: number[];
  createdAt: Date;
  updatedAt: Date;
  bars: any[];
}
