import { useState, useEffect } from "react";
import { X, Share2, Heart, Navigation, Plus, Star, MapPin, Phone, Globe, Clock, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

interface BarModalProps {
  isOpen: boolean;
  onClose: () => void;
  bar: any;
  isSaved?: boolean;
  onSaveToggle: (barId: number) => void;
  onAddToHop: (bar: any) => void;
}

export function BarModal({ 
  isOpen, 
  onClose, 
  bar, 
  isSaved, 
  onSaveToggle, 
  onAddToHop 
}: BarModalProps) {
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  
  // Fetch detailed bar information from Google Places API
  const { data: barDetails, isLoading } = useQuery({
    queryKey: ["bar-details", bar?.place_id],
    queryFn: async () => {
      if (!bar?.place_id) return null;
      
      const GOOGLE_PLACES_API_KEY = import.meta.env.VITE_GOOGLE_PLACES_API_KEY;
      
      if (!GOOGLE_PLACES_API_KEY) {
        throw new Error("Google Places API key not found");
      }

      const response = await fetch(`https://places.googleapis.com/v1/places/${bar.place_id}`, {
        headers: {
          'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY,
          'X-Goog-FieldMask': 'displayName,formattedAddress,rating,priceLevel,photos,currentOpeningHours,internationalPhoneNumber,website,types,reviews'
        }
      });

      if (!response.ok) {
        throw new Error("Failed to fetch bar details");
      }

      const data = await response.json();
      
      return {
        name: data.displayName?.text || bar.name,
        address: data.formattedAddress || bar.formatted_address,
        rating: data.rating || bar.rating,
        priceLevel: data.priceLevel || bar.price_level,
        photos: data.photos?.map((photo: any) => 
          `https://places.googleapis.com/v1/${photo.name}/media?maxWidthPx=800&key=${GOOGLE_PLACES_API_KEY}`
        ) || bar.photos || [],
        hours: data.currentOpeningHours,
        phone: data.internationalPhoneNumber,
        website: data.website,
        types: data.types || bar.types || [],
        reviews: data.reviews || []
      };
    },
    enabled: !!(isOpen && bar?.place_id),
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  if (!bar) return null;

  const displayData = barDetails || bar;
  const photos = displayData.photos || [];

  const handleSaveToggle = () => {
    onSaveToggle(bar.id || bar.place_id);
  };

  const handleAddToHop = () => {
    onAddToHop(bar);
  };

  const handleGetDirections = () => {
    const address = displayData.address || displayData.formatted_address;
    const url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;
    window.open(url, '_blank');
  };

  const getPriceLevel = () => {
    if (!displayData.priceLevel) return "";
    return "$".repeat(Math.min(displayData.priceLevel, 4));
  };

  const formatPhoneNumber = (phone: string) => {
    if (!phone || typeof phone !== 'string') return "";
    return phone.replace(/^\+1/, "");
  };

  const nextPhoto = () => {
    if (photos.length > 1) {
      setCurrentPhotoIndex((prev) => (prev + 1) % photos.length);
    }
  };

  const prevPhoto = () => {
    if (photos.length > 1) {
      setCurrentPhotoIndex((prev) => (prev - 1 + photos.length) % photos.length);
    }
  };

  const getOpeningHoursToday = () => {
    if (!displayData.hours?.weekdayText) return null;
    const today = new Date().getDay();
    const todayIndex = today === 0 ? 6 : today - 1; // Convert to Monday = 0 format
    return displayData.hours.weekdayText[todayIndex];
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto p-0">
        <DialogTitle className="sr-only">Bar Details for {displayData.name}</DialogTitle>
        <DialogDescription className="sr-only">
          Detailed information about {displayData.name} including photos, hours, ratings, and contact information.
        </DialogDescription>
        {/* Header */}
        <div className="relative">
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute top-4 left-4 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white/90 z-20"
          >
            <X className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white/90 z-20"
          >
            <Share2 className="h-5 w-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="pb-6 space-y-6">
          {/* Photo Gallery */}
          {photos.length > 0 ? (
            <div className="relative h-64 w-full">
              <img 
                src={photos[currentPhotoIndex]} 
                alt={displayData.name}
                className="w-full h-full object-cover"
              />
              
              {/* Photo Navigation */}
              {photos.length > 1 && (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={prevPhoto}
                    className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 rounded-full hover:bg-opacity-70"
                  >
                    <ChevronLeft className="h-5 w-5 text-white" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={nextPhoto}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 rounded-full hover:bg-opacity-70"
                  >
                    <ChevronRight className="h-5 w-5 text-white" />
                  </Button>
                  
                  {/* Photo indicators */}
                  <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex space-x-1">
                    {photos.map((_: any, index: number) => (
                      <button
                        key={index}
                        onClick={() => setCurrentPhotoIndex(index)}
                        className={`w-2 h-2 rounded-full ${
                          index === currentPhotoIndex ? 'bg-white' : 'bg-white bg-opacity-50'
                        }`}
                      />
                    ))}
                  </div>
                </>
              )}
              
              {/* Save button */}
              <div className="absolute top-3 right-3">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleSaveToggle}
                  className={`bg-black bg-opacity-60 rounded-full p-3 hover:bg-opacity-80 ${
                    isSaved ? 'text-red-500' : 'text-white hover:text-red-500'
                  }`}
                >
                  <Heart className={`h-6 w-6 ${isSaved ? 'fill-current' : ''}`} />
                </Button>
              </div>
              
              {/* Open/Closed status */}
              {displayData.hours && (
                <div className={`absolute bottom-3 left-3 px-3 py-1 rounded-full text-sm font-medium ${
                  displayData.hours.openNow ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
                }`}>
                  {displayData.hours.openNow ? 'Open Now' : 'Closed'}
                </div>
              )}
            </div>
          ) : (
            <div className="h-64 bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
              <span className="text-white text-4xl font-bold">
                {displayData.name?.split(' ').map((w: string) => w[0]).join('').slice(0, 2)}
              </span>
            </div>
          )}

          {/* Bar Info */}
          <div className="px-4 space-y-4">
            <div>
              <h1 className="text-2xl font-bold mb-2">{displayData.name}</h1>
              <div className="flex items-center gap-4 text-sm text-gray-600 flex-wrap">
                {displayData.rating && (
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span>
                      {displayData.rating.toFixed(1)}
                      {displayData.reviews && ` (${displayData.reviews.length} reviews)`}
                    </span>
                  </div>
                )}
                {getPriceLevel() && (
                  <span className="text-gray-500">{getPriceLevel()}</span>
                )}
              </div>
            </div>

            {/* Address */}
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-gray-400 mt-0.5 flex-shrink-0" />
              <span className="text-gray-700">{displayData.address || displayData.formatted_address}</span>
            </div>

            {/* Hours */}
            {displayData.hours && (
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-gray-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <div className={`font-medium ${displayData.hours.openNow ? 'text-green-600' : 'text-red-600'}`}>
                    {displayData.hours.openNow ? 'Open' : 'Closed'}
                  </div>
                  {getOpeningHoursToday() && (
                    <div className="text-sm text-gray-600 mt-1">{getOpeningHoursToday()}</div>
                  )}
                  {displayData.hours.weekdayText && (
                    <div className="mt-2 space-y-1">
                      <div className="text-sm font-medium text-gray-700">Hours:</div>
                      {displayData.hours.weekdayText.map((dayHours: string, index: number) => (
                        <div key={index} className="text-xs text-gray-600">{dayHours}</div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Phone */}
            {displayData.phone && (
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-gray-400 flex-shrink-0" />
                <a 
                  href={`tel:${displayData.phone}`}
                  className="text-blue-600 hover:underline"
                >
                  {formatPhoneNumber(displayData.phone)}
                </a>
              </div>
            )}

            {/* Website */}
            {displayData.website && (
              <div className="flex items-center gap-3">
                <Globe className="h-5 w-5 text-gray-400 flex-shrink-0" />
                <a 
                  href={displayData.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  Visit Website
                </a>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button 
                onClick={handleGetDirections}
                className="flex-1"
              >
                <Navigation className="h-4 w-4 mr-2" />
                Directions
              </Button>
              <Button 
                onClick={handleAddToHop}
                variant="outline"
                className="flex-1"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add to Hop
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}