import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { MapPin, Star, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { BarModal } from "@/components/BarModal";

interface FeaturedBar {
  place_id: string;
  name: string;
  formatted_address: string;
  rating?: number;
  price_level?: number;
  photos?: string[];
  opening_hours?: {
    open_now: boolean;
  };
  types: string[];
}

interface UserLocation {
  latitude: number;
  longitude: number;
  address?: string;
}

export default function HomePage() {
  const [userLocation, setUserLocation] = useState<UserLocation | null>(() => {
    // Load saved location from localStorage
    const saved = localStorage.getItem('userLocation');
    return saved ? JSON.parse(saved) : null;
  });
  const [selectedBar, setSelectedBar] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Get user location on component mount if not already saved
  useEffect(() => {
    if (!userLocation) {
      getUserLocation();
    }
  }, [userLocation]);

  const getUserLocation = async () => {
    if ("geolocation" in navigator) {
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000, // 5 minutes
          });
        });

        const location: UserLocation = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        };

        // Save location to localStorage and state
        localStorage.setItem('userLocation', JSON.stringify(location));
        setUserLocation(location);
      } catch (error) {
        console.error("Error getting location:", error);
        // Fallback to Chicago if location fails
        const chicagoLocation: UserLocation = {
          latitude: 41.8781,
          longitude: -87.6298,
          address: "Chicago, IL"
        };
        localStorage.setItem('userLocation', JSON.stringify(chicagoLocation));
        setUserLocation(chicagoLocation);
      }
    }
  };

  // Get featured bars using Google Places API directly
  const { data: featuredData, isLoading, error } = useQuery({
    queryKey: ["featured-bars", userLocation?.latitude, userLocation?.longitude],
    queryFn: async () => {
      if (!userLocation) {
        throw new Error("Location not available");
      }

      const GOOGLE_PLACES_API_KEY = import.meta.env.VITE_GOOGLE_PLACES_API_KEY;
      
      if (!GOOGLE_PLACES_API_KEY) {
        throw new Error("Google Places API key not found");
      }

      const requestBody = {
        includedTypes: ["bar", "night_club"],
        maxResultCount: 20,
        locationRestriction: {
          circle: {
            center: {
              latitude: userLocation.latitude,
              longitude: userLocation.longitude
            },
            radius: 15000 // 15km radius
          }
        }
      };

      const response = await fetch('https://places.googleapis.com/v1/places:searchNearby', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY,
          'X-Goog-FieldMask': 'places.displayName,places.formattedAddress,places.rating,places.priceLevel,places.photos,places.location,places.types,places.id,places.currentOpeningHours'
        },
        body: JSON.stringify(requestBody)
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(`API Error: ${data.error?.message || 'Failed to fetch bars'}`);
      }

      // Transform to match expected format and randomly select 5
      const allBars = (data.places || []).map((place: any) => ({
        place_id: place.id,
        name: place.displayName?.text || '',
        formatted_address: place.formattedAddress || '',
        rating: place.rating,
        price_level: place.priceLevel,
        photos: place.photos?.map((photo: any) => 
          `https://places.googleapis.com/v1/${photo.name}/media?maxWidthPx=400&key=${GOOGLE_PLACES_API_KEY}`
        ) || [],
        opening_hours: place.currentOpeningHours ? {
          open_now: place.currentOpeningHours.openNow
        } : undefined,
        types: place.types || []
      }));
      
      // Randomly shuffle and select 5 bars
      const shuffled = allBars.sort(() => 0.5 - Math.random());
      const randomBars = shuffled.slice(0, 5);
      
      return { bars: randomBars };
    },
    enabled: !!userLocation, // Only run query when location is available
    staleTime: 10 * 60 * 1000, // 10 minutes
    retry: 3,
  });

  const featuredBars = featuredData?.bars || [];

  // Log errors for debugging
  useEffect(() => {
    if (error) {
      console.error("Featured bars error:", error);
    }
  }, [error]);

  const handleBarClick = (bar: any) => {
    setSelectedBar(bar);
    setIsModalOpen(true);
  };

  const handleSaveToggle = (barId: number) => {
    // Handle save/unsave logic here
    console.log("Toggle save for bar:", barId);
  };

  const handleAddToHop = (bar: any) => {
    // Handle add to bar hop logic here
    console.log("Add to hop:", bar);
  };

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      {/* Hero Section */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-4">Plan the Perfect Night Out</h1>
        <p className="text-xl text-gray-600 mb-6">
          Discover amazing bars and create your very own bar hop with friends - from craft cocktails to dive bars
        </p>
      </div>

      {/* Featured Bars & Clubs Section */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Featured Bars & Clubs</h2>
          <Link href="/search">
            <Button variant="ghost">View All →</Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {[...Array(5)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-32 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {featuredBars.map((bar: FeaturedBar) => (
              <Card 
                key={bar.place_id} 
                className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => handleBarClick(bar)}
              >
                <div className="relative">
                  {bar.photos && bar.photos[0] ? (
                    <img 
                      src={bar.photos[0]} 
                      alt={bar.name}
                      className="w-full h-48 object-cover"
                    />
                  ) : (
                    <div className="w-full h-48 bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
                      <span className="text-white text-2xl font-bold">
                        {bar.name.split(' ').map(w => w[0]).join('').slice(0, 2)}
                      </span>
                    </div>
                  )}
                  
                  {bar.opening_hours?.open_now && (
                    <Badge className="absolute top-2 right-2 bg-green-500">
                      <Clock className="h-3 w-3 mr-1" />
                      Open Now
                    </Badge>
                  )}
                </div>
                
                <CardContent className="p-4">
                  <div className="mb-2">
                    <h3 className="font-semibold text-lg truncate">{bar.name}</h3>
                    <p className="text-sm text-gray-600 truncate">{bar.formatted_address}</p>
                  </div>
                  
                  <div className="flex items-center justify-between mb-2">
                    {bar.rating && (
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="ml-1 text-sm">{bar.rating}</span>
                      </div>
                    )}
                    
                    {bar.price_level && (
                      <div className="text-sm text-gray-500">
                        {'$'.repeat(bar.price_level)}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    {bar.types
                      .filter(type => ['bar', 'night_club', 'restaurant'].includes(type))
                      .slice(0, 1)
                      .map((type) => (
                        <Badge key={type} variant="secondary" className="text-xs">
                          {type === 'night_club' ? 'Club' : type}
                        </Badge>
                      ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Bar Modal */}
      <BarModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        bar={selectedBar}
        onSaveToggle={handleSaveToggle}
        onAddToHop={handleAddToHop}
      />
    </div>
  );
}