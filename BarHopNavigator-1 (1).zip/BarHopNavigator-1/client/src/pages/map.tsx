import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { MapPin, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { barApi } from "@/lib/api";

interface UserLocation {
  latitude: number;
  longitude: number;
  address?: string;
}

export default function MapPage() {
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [viewMode, setViewMode] = useState<"map" | "list">("map");
  const mapRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<google.maps.Map | null>(null);
  const userMarkerRef = useRef<google.maps.Marker | null>(null);
  const barMarkersRef = useRef<google.maps.Marker[]>([]);

  useEffect(() => {
    // Load location from localStorage or get current location
    const savedLocation = localStorage.getItem('userLocation');
    if (savedLocation) {
      try {
        const parsedLocation = JSON.parse(savedLocation);
        setUserLocation({ 
          latitude: parsedLocation.latitude, 
          longitude: parsedLocation.longitude 
        });
      } catch (e) {
        console.error("Error parsing saved location:", e);
      }
    }
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const newLocation = { latitude, longitude };
          setUserLocation(newLocation);
          localStorage.setItem('userLocation', JSON.stringify(newLocation));
        },
        (error) => {
          console.error("Location error:", error);
        },
      );
    }
  }, []);

  // Use address when available, fall back to coordinates - same as search page
  const locationString = userLocation
    ? (userLocation.address || `${userLocation.latitude},${userLocation.longitude}`)
    : null;

  const { data: searchResponse, isLoading } = useQuery({
    queryKey: ["bars-search", "", locationString], // Same query key format as search page
    enabled: !!locationString,
    queryFn: () => {
      if (locationString) {
        return barApi.searchBars("", locationString); // Same call as search page
      }
      return Promise.resolve({ bars: [], status: "OK" });
    },
  });

  const nearbyBars = searchResponse?.bars || [];

  // Initialize Google Map
  useEffect(() => {
    if (userLocation && mapRef.current && !googleMapRef.current) {
      // Check if Google Maps is loaded
      if (typeof google === "undefined") {
        // Load Google Maps script if not already loaded
        const script = document.createElement("script");
        script.src = `https://maps.googleapis.com/maps/api/js?key=${import.meta.env.VITE_GOOGLE_PLACES_API_KEY}&libraries=places`;
        script.async = true;
        script.onload = () => initializeMap();
        document.head.appendChild(script);
      } else {
        initializeMap();
      }
    }
  }, [userLocation]);

  const initializeMap = () => {
    if (!userLocation || !mapRef.current) return;

    // Create map with clean interface - no satellite view or unnecessary controls
    googleMapRef.current = new google.maps.Map(mapRef.current, {
      center: { lat: userLocation.latitude, lng: userLocation.longitude },
      zoom: 15,
      mapTypeControl: false, // Remove satellite/terrain options
      streetViewControl: false, // Remove street view
      fullscreenControl: false, // Remove fullscreen button
      zoomControl: true, // Keep zoom controls
      gestureHandling: "greedy",
      styles: [
        // Dark theme for the map
        { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
        { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
        { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
        {
          featureType: "administrative.locality",
          elementType: "labels.text.fill",
          stylers: [{ color: "#d59563" }],
        },
        {
          featureType: "poi",
          elementType: "labels.text.fill",
          stylers: [{ color: "#d59563" }],
        },
        {
          featureType: "poi.park",
          elementType: "geometry",
          stylers: [{ color: "#263c3f" }],
        },
        {
          featureType: "poi.park",
          elementType: "labels.text.fill",
          stylers: [{ color: "#6b9a76" }],
        },
        {
          featureType: "road",
          elementType: "geometry",
          stylers: [{ color: "#38414e" }],
        },
        {
          featureType: "road",
          elementType: "geometry.stroke",
          stylers: [{ color: "#212a37" }],
        },
        {
          featureType: "road",
          elementType: "labels.text.fill",
          stylers: [{ color: "#9ca5b3" }],
        },
        {
          featureType: "road.highway",
          elementType: "geometry",
          stylers: [{ color: "#746855" }],
        },
        {
          featureType: "road.highway",
          elementType: "geometry.stroke",
          stylers: [{ color: "#1f2835" }],
        },
        {
          featureType: "road.highway",
          elementType: "labels.text.fill",
          stylers: [{ color: "#f3d19c" }],
        },
        {
          featureType: "transit",
          elementType: "geometry",
          stylers: [{ color: "#2f3948" }],
        },
        {
          featureType: "transit.station",
          elementType: "labels.text.fill",
          stylers: [{ color: "#d59563" }],
        },
        {
          featureType: "water",
          elementType: "geometry",
          stylers: [{ color: "#17263c" }],
        },
        {
          featureType: "water",
          elementType: "labels.text.fill",
          stylers: [{ color: "#515c6d" }],
        },
        {
          featureType: "water",
          elementType: "labels.text.stroke",
          stylers: [{ color: "#17263c" }],
        },
      ],
    });

    // Add user location marker
    userMarkerRef.current = new google.maps.Marker({
      position: { lat: userLocation.latitude, lng: userLocation.longitude },
      map: googleMapRef.current,
      title: "Your Location",
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 10,
        fillColor: "#ff1493", // vibrant pink
        fillOpacity: 1,
        strokeColor: "#ffffff",
        strokeWeight: 2,
      },
    });
  };

  // Update map with bar markers
  useEffect(() => {
    if (googleMapRef.current && nearbyBars.length > 0) {
      // Clear existing bar markers
      barMarkersRef.current.forEach((marker) => marker.setMap(null));
      barMarkersRef.current = [];

      // Add new bar markers
      nearbyBars.forEach((bar: any) => {
        if (bar.latitude && bar.longitude) {
          const marker = new google.maps.Marker({
            position: { lat: bar.latitude, lng: bar.longitude },
            map: googleMapRef.current,
            title: bar.name,
            icon: {
              path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
              scale: 6,
              fillColor: "#ffd700", // gold color for bars
              fillOpacity: 1,
              strokeColor: "#ffffff",
              strokeWeight: 1,
            },
          });

          // Add info window for each bar
          const infoWindow = new google.maps.InfoWindow({
            content: `
              <div style="color: #333; padding: 8px;">
                <h3 style="margin: 0 0 8px 0; font-size: 16px; font-weight: bold;">${bar.name}</h3>
                <p style="margin: 0 0 4px 0; font-size: 14px;">${bar.address || "Address not available"}</p>
                ${bar.rating ? `<p style="margin: 0; font-size: 14px;">★ ${bar.rating.toFixed(1)}</p>` : ""}
              </div>
            `,
          });

          marker.addListener("click", () => {
            infoWindow.open(googleMapRef.current, marker);
          });

          barMarkersRef.current.push(marker);
        }
      });
    }
  }, [nearbyBars]);

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      {/* Header */}
      <header className="bg-navy-darker px-4 py-6 sticky top-0 z-40">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="text-vibrant-pink text-xl" />
            <span className="text-lg font-semibold">Map View</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setViewMode(viewMode === "map" ? "list" : "map")}
            className="text-vibrant-pink hover:text-vibrant-pink/80"
          >
            {viewMode === "map" ? (
              <List className="h-5 w-5" />
            ) : (
              <MapPin className="h-5 w-5" />
            )}
          </Button>
        </div>
      </header>

      <main className="px-4 pb-24">
        {/* Always show map section when user location is available */}
        {userLocation ? (
          <div className="bg-navy-darker rounded-xl overflow-hidden mb-6">
            {/* Map Container */}
            <div ref={mapRef} className="h-[500px] w-full"></div>

            {/* Map Info Overlay */}
            <div className="p-4 text-center border-t border-navy-light">
              <h3 className="text-lg font-medium text-white mb-2">
                Interactive Map
              </h3>
              <p className="text-gray-400 mb-2">
                {isLoading
                  ? "Loading nearby bars..."
                  : nearbyBars.length > 0
                    ? `Showing ${nearbyBars.length} nearby bars`
                    : "No nearby bars found, but showing your location"}
              </p>
              <p className="text-sm text-gray-500">
                Your Location: {userLocation.latitude.toFixed(4)},{" "}
                {userLocation.longitude.toFixed(4)}
              </p>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-300 mb-2">
              Location Required
            </h3>
            <p className="text-gray-400">
              Please enable location access to view the map
            </p>
          </div>
        )}

        {/* Show loading state */}
        {isLoading && userLocation && (
          <div className="flex items-center justify-center py-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-vibrant-pink mx-auto mb-2"></div>
              <p className="text-gray-400">Searching for nearby bars...</p>
            </div>
          </div>
        )}

        {/* Show nearby bars list if any are found */}
        {nearbyBars.length > 0 && (
          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-4">
              Nearby Bars ({nearbyBars.length})
            </h3>
            <div className="space-y-3">
              {nearbyBars.slice(0, 5).map((bar: any) => (
                <div key={bar.id} className="bg-navy-darker rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-white">{bar.name}</h4>
                      <p className="text-sm text-gray-400">{bar.address}</p>
                      {bar.rating && (
                        <div className="flex items-center gap-1 mt-1">
                          <span className="text-yellow-400">★</span>
                          <span className="text-sm text-gray-300">
                            {bar.rating.toFixed(1)}
                          </span>
                        </div>
                      )}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-vibrant-pink text-vibrant-pink hover:bg-vibrant-pink hover:text-white"
                    >
                      View
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Show message when no bars found but location is available */}
        {!isLoading && userLocation && nearbyBars.length === 0 && (
          <div className="text-center py-8 bg-navy-darker rounded-xl">
            <h3 className="text-lg font-medium text-gray-300 mb-2">
              No Nearby Bars Found
            </h3>
            <p className="text-gray-400 mb-4">
              We couldn't find any bars in your immediate area, but your
              location is shown on the map above.
            </p>
            <p className="text-sm text-gray-500">
              Try searching for bars in a different area or check back later.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
